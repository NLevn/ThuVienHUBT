<?php
include 'connection.php'; // Kết nối tới cơ sở dữ liệu
session_start();

// Kiểm tra quyền admin
if ($_SESSION['role'] != 'admin') {
    echo "Bạn không có quyền truy cập vào trang này.";
    exit();
}

// Thêm thủ thư mới
if (isset($_POST['add_librarian'])) {
    $first = $_POST['first'];
    $last = $_POST['last'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $pic = $_POST['pic']; // Đường dẫn hoặc tên file ảnh thủ thư
    $status = $_POST['status'];

    $sql = "INSERT INTO librarian (first, last, username, password, email, contact, pic, status) 
            VALUES ('$first', '$last', '$username', '$password', '$email', '$contact', '$pic', '$status')";
    if (mysqli_query($conn, $sql)) {
        echo "Thêm thủ thư thành công!";
    } else {
        echo "Lỗi: " . mysqli_error($conn);
    }
}

// Thêm người dùng mới
if (isset($_POST['add_user'])) {
    $bid = $_POST['bid'];
    $name = $_POST['name'];
    $authors = $_POST['authors'];
    $username = $_POST['username'];
    $added_at = $_POST['added_at'];

    $sql = "INSERT INTO users (bid, name, authors, username, added_at) 
            VALUES ('$bid', '$name', '$authors', '$username', '$added_at')";
    if (mysqli_query($conn, $sql)) {
        echo "Thêm người dùng thành công!";
    } else {
        echo "Lỗi: " . mysqli_error($conn);
    }
}

// Cập nhật thông tin thủ thư
if (isset($_POST['edit_librarian'])) {
    $id = $_POST['id'];
    $first = $_POST['first'];
    $last = $_POST['last'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $status = $_POST['status'];

    $sql = "UPDATE librarian SET first='$first', last='$last', username='$username', email='$email', contact='$contact', status='$status' WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
        echo "Cập nhật thủ thư thành công!";
    } else {
        echo "Lỗi: " . mysqli_error($conn);
    }
}

// Cập nhật thông tin người dùng
if (isset($_POST['edit_user'])) {
    $id = $_POST['id'];
    $bid = $_POST['bid'];
    $name = $_POST['name'];
    $authors = $_POST['authors'];
    $username = $_POST['username'];

    $sql = "UPDATE users SET bid='$bid', name='$name', authors='$authors', username='$username' WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
        echo "Cập nhật người dùng thành công!";
    } else {
        echo "Lỗi: " . mysqli_error($conn);
    }
}

// Xóa thủ thư
if (isset($_POST['delete_librarian'])) {
    $id = $_POST['id'];

    $sql = "DELETE FROM librarian WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
        echo "Xóa thủ thư thành công!";
    } else {
        echo "Lỗi: " . mysqli_error($conn);
    }
}

// Xóa người dùng
if (isset($_POST['delete_user'])) {
    $id = $_POST['id'];

    $sql = "DELETE FROM users WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
        echo "Xóa người dùng thành công!";
    } else {
        echo "Lỗi: " . mysqli_error($conn);
    }
}

// Lấy danh sách thủ thư
$librarian_sql = "SELECT * FROM librarian";
$librarian_result = mysqli_query($conn, $librarian_sql);

// Lấy danh sách người dùng
$user_sql = "SELECT * FROM users";
$user_result = mysqli_query($conn, $user_sql);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý người dùng</title>
</head>
<body>
    <h1>Quản lý thủ thư và người dùng</h1>

    <!-- Form thêm thủ thư -->
    <h2>Thêm thủ thư mới</h2>
    <form action="manage_users.php" method="post">
        <label for="first">First Name:</label>
        <input type="text" id="first" name="first" required><br>
        
        <label for="last">Last Name:</label>
        <input type="text" id="last" name="last" required><br>
        
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br>
        
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br>
        
        <label for="email">Email:</label>
        <input type="email" id="email" name="email"><br>
        
        <label for="contact">Contact:</label>
        <input type="text" id="contact" name="contact"><br>
        
        <label for="pic">Picture:</label>
        <input type="text" id="pic" name="pic"><br>
        
        <label for="status">Status:</label>
        <input type="text" id="status" name="status"><br>
        
        <button type="submit" name="add_librarian">Thêm thủ thư</button>
    </form>

    <!-- Form thêm người dùng -->
    <h2>Thêm người dùng mới</h2>
    <form action="manage_users.php" method="post">
        <label for="bid">Book ID:</label>
        <input type="text" id="bid" name="bid" required><br>

        <label for="name">Book Name:</label>
        <input type="text" id="name" name="name" required><br>

        <label for="authors">Authors:</label>
        <input type="text" id="authors" name="authors" required><br>

        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br>

        <label for="added_at">Added At:</label>
        <input type="date" id="added_at" name="added_at" required><br>

        <button type="submit" name="add_user">Thêm người dùng</button>
    </form>

    <!-- Danh sách thủ thư -->
    <h2>Danh sách thủ thư</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>First</th>
            <th>Last</th>
            <th>Username</th>
            <th>Email</th>
            <th>Contact</th>
            <th>Status</th>
            <th>Thao tác</th>
        </tr>

        <?php while ($librarian = mysqli_fetch_assoc($librarian_result)) { ?>
            <tr>
                <td><?php echo $librarian['id']; ?></td>
                <td><?php echo $librarian['first']; ?></td>
                <td><?php echo $librarian['last']; ?></td>
                <td><?php echo $librarian['username']; ?></td>
                <td><?php echo $librarian['email']; ?></td>
                <td><?php echo $librarian['contact']; ?></td>
                <td><?php echo $librarian['status']; ?></td>
                <td>
                    <!-- Form sửa thủ thư -->
                    <form action="manage_users.php" method="post" style="display:inline-block;">
                        <input type="hidden" name="id" value="<?php echo $librarian['id']; ?>">
                        <input type="text" name="first" value="<?php echo $librarian['first']; ?>" required>
                        <input type="text" name="last" value="<?php echo $librarian['last']; ?>" required>
                        <input type="email" name="email" value="<?php echo $librarian['email']; ?>">
                        <input type="text" name="contact" value="<?php echo $librarian['contact']; ?>">
                        <input type="text" name="status" value="<?php echo $librarian['status']; ?>">
                        <button type="submit" name="edit_librarian">Cập nhật</button>
                    </form>

                    <!-- Form xóa thủ thư -->
                    <form action="manage_users.php" method="post" style="display:inline-block;">
                        <input type="hidden" name="id" value="<?php echo $librarian['id']; ?>">
                        <button type="submit" name="delete_librarian">Xóa</button>
                    </form>
                </td>
            </tr>
        <?php } ?>
    </table>

    <!-- Danh sách người dùng -->
    <h2>Danh sách người dùng</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Book ID</th>
            <th>Book Name</th>
            <th>Authors</th>
            <th>Username</th>
            <th>Added At</th>
            <th>Thao tác</th>
        </tr>

        <?php while ($user = mysqli_fetch_assoc($user_result)) { ?>
            <tr>
                <td><?php echo $user['id']; ?></td>
                <td><?php echo $user['bid']; ?></td>
                <td><?php echo $user['name']; ?></td>
                <td><?php echo $user['authors']; ?></td>
                <td><?php echo $user['username']; ?></td>
                <td><?php echo $user['added_at']; ?></td>
                <td>
                    <!-- Form sửa người dùng -->
                    <form action="manage_users.php" method="post" style="display:inline-block;">
                        <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                        <input type="text" name="bid" value="<?php echo $user['bid']; ?>" required>
                        <input type="text" name="name" value="<?php echo $user['name']; ?>" required>
                        <input type="text" name="authors" value="<?php echo $user['authors']; ?>" required>
                        <input type="text" name="username" value="<?php echo $user['username']; ?>" required>
                        <button type="submit" name="edit_user">Cập nhật</button>
                    </form>

                    <!-- Form xóa người dùng -->
                    <form action="manage_users.php" method="post" style="display:inline-block;">
                        <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                        <button type="submit" name="delete_user">Xóa</button>
                    </form>
                </td>
            </tr>
        <?php } ?>
    </table>

</body>
</html>
