<?php
session_start();
include '../QuanTri/connection.php'; // Đường dẫn đến file kết nối cơ sở dữ liệu

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Lấy thông tin từ form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Truy vấn cơ sở dữ liệu để kiểm tra người dùng
    $query = "SELECT * FROM admin WHERE username = ? LIMIT 1";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();

        // Kiểm tra mật khẩu
        if (password_verify($password, $row['password'])) {
            // Lưu thông tin vào session
            $_SESSION['username'] = $row['username'];
            $_SESSION['role'] = 'admin'; // Đặt vai trò là admin

            // Chuyển hướng đến trang quản lý người dùng
            header("Location: manage_users.php");
            exit();
        } else {
            echo "Mật khẩu không chính xác.";
        }
    } else {
        echo "Tên người dùng không tồn tại.";
    }
}

$conn->close(); // Đóng kết nối
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng Nhập Quản Trị</title>
    <link rel="stylesheet" href="style.css"> <!-- Đường dẫn đến file CSS -->
</head>
<body>
    <h2>Đăng Nhập Quản Trị</h2>
    <form action="admin_login.php" method="POST">
        <label for="username">Tên người dùng:</label>
        <input type="text" id="username" name="username" required>
        
        <label for="password">Mật khẩu:</label>
        <input type="password" id="password" name="password" required>
        
        <button type="submit">Đăng Nhập</button>
    </form>
</body>
</html>
