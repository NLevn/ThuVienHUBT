<?php
include '../QuanTri/connection.php'; // Đường dẫn đến file kết nối cơ sở dữ liệu

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Lấy thông tin từ form
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];

    // Mã hóa mật khẩu
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Truy vấn để thêm tài khoản mới
    $query = "INSERT INTO admin (username, password, email, contact) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssss", $username, $hashed_password, $email, $contact);

    if ($stmt->execute()) {
        echo "Tạo tài khoản quản trị thành công!";
    } else {
        echo "Lỗi: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close(); // Đóng kết nối
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tạo Tài Khoản Quản Trị</title>
    <link rel="stylesheet" href="style.css"> <!-- Đường dẫn đến file CSS -->
</head>
<body>
    <h2>Tạo Tài Khoản Quản Trị</h2>
    <form action="create_admin.php" method="POST">
        <label for="username">Tên người dùng:</label>
        <input type="text" id="username" name="username" required>
        
        <label for="password">Mật khẩu:</label>
        <input type="password" id="password" name="password" required>
        
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
        
        <label for="contact">Số điện thoại:</label>
        <input type="text" id="contact" name="contact">
        
        <button type="submit">Tạo Tài Khoản</button>
    </form>
</body>
</html>
