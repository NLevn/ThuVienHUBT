<?php
session_start();

// Kết nối đến cơ sở dữ liệu MySQL
$servername = "localhost"; // Tên máy chủ
$username = "root"; // Tên đăng nhập MySQL
$password = ""; // Mật khẩu MySQL
$dbname = "library"; // Tên cơ sở dữ liệu

$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Kết nối thất bại: " . $conn->connect_error);
}

// Lấy thông tin session và IP của người dùng
$session_id = session_id();
$ip_address = $_SERVER['REMOTE_ADDR'];
$today = date('Y-m-d');

// Kiểm tra xem session này đã được ghi nhận chưa
$sql = "SELECT * FROM visit_counter WHERE session_id='$session_id' AND visit_date='$today'";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    // Nếu chưa, thêm vào bảng visit_counter
    $sql = "INSERT INTO visit_counter (session_id, ip_address, visit_date) VALUES ('$session_id', '$ip_address', '$today')";
    $conn->query($sql);
}

// Đếm số người đang online (khoảng thời gian xem là online: 5 phút)
$time_online = 5 * 60; // 5 phút
$sql = "SELECT COUNT(DISTINCT session_id) AS online_count FROM visit_counter WHERE visit_date = '$today' AND TIMESTAMPDIFF(SECOND, visit_date, NOW()) <= $time_online";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$online_count = $row['online_count'];

// Đếm số lượt truy cập trong ngày
$sql = "SELECT COUNT(*) AS today_count FROM visit_counter WHERE visit_date='$today'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$today_count = $row['today_count'];

// Đếm tổng số lượt truy cập
$sql = "SELECT COUNT(*) AS total_count FROM visit_counter";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$total_count = $row['total_count'];

$conn->close();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <title>Online Library Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style type="text/css">
        body, html {
            margin: 0;
            padding: 0;
            width: 100%;
            font-family: Arial, Helvetica, sans-serif;
            overflow-x: hidden;
        }

        .wrapper {
            width: 100%;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        header {
            width: 100%;
            background-color: #704f4f;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 82px;
            position: relative;
            z-index: 1000;
        }

        .logo img {
            max-height: 65px;
            padding-left: 5px;
            margin-top: -2px;
        }

        nav ul {
            padding: 0;
            margin: 0;
            list-style: none;
            display: flex;
            gap: 20px;
        }

        nav li {
            line-height: 80px;
            text-decoration: none;
        }

        nav a {
            text-decoration: none;
            color: white;
            padding: 10px 12px;
            transition: background-color 0.3s;
            padding-right: 26px;
        }

        nav a:hover {
            background-color: #ddd;
            color: #000;
            text-decoration: none;
        }

        .content {
            display: flex;
            justify-content: center; /* Căn giữa nội dung của content */
            align-items: flex-start;
            gap: 20px; /* Khoảng cách giữa ảnh và container */
            margin: 20px auto;
            width: 85%;
        }

        .anh {
            flex: 1;
            border-radius: 5px;
            overflow: hidden;
        }

        .carousel-inner {
            width: 100%;
            max-height: 500px;
        }

        .carousel-item img {
            width: 100%;
            height: 500px;
            object-fit: cover;
            border-radius: 5px;
        }

        .container {
            width: 230px; /* Chiều rộng cố định */
            background-color: #ffeb3b;
            border-top: 5px solid red;
            padding: 10px;
            box-sizing: border-box;
            margin: 0; /* Không cần margin auto */
            align-self: flex-start;
        }

        .container .item {
            margin-bottom: 10px;
        }

        .banner {
            text-align: center;
            padding: 20px;
            background-color: #f0f0f0;
            margin-top: 20px;
        }
        .banner h1 {
            margin: 0;
            color: #333;
            font-size: 2em;
        }

        .banner p {
            margin: 5px 0;
            color: #555;
        }

        .social-icons a {
            text-decoration: none;
            color: #1e7231;
            margin: 0 10px;
            font-weight: bold;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px 0;
            width: 100%;
            box-sizing: border-box;
            margin-top: auto;
        }
    </style>
</head>

<body>
    <div class="wrapper">
        <header>
            <div class="logo">
                <img src="images/logo2.png">
                <h1 style="color: white; float: right; margin-top: 8px;">Thư viện HUBT</h1>
            </div>

            <?php if(isset($_SESSION['login_user'])): ?>
                <nav>
                    <ul>
                        <li><a href="index.php">TRANG CHỦ</a></li>
                        <li><a href="books.php">SÁCH</a></li>
                        <li><a href="logout.php">ĐĂNG XUẤT</a></li>
                        <li><a href="feedback.php">PHẢN HỒI</a></li>
                    </ul>
                </nav>
            <?php else: ?>
                <nav>
                    <ul>
                        <li><a href="index.php">TRANG CHỦ</a></li>
                        <li><a href="books.php">SÁCH</a></li>
                        <li><a href="login.php">ĐĂNG NHẬP</a></li>
                        <li><a href="registration.php">ĐĂNG KÍ</a></li>
                        <li><a href="feedback.php">PHẢN HỒI</a></li>
                    </ul>
                </nav>
            <?php endif; ?>
        </header>

        <div class="content">
            <div class="anh">
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" data-interval="2000">
                    <ol class="carousel-indicators">
                        <!-- <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="3"></li> -->
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img class="d-block w-100" src="./images/1.jpg" alt="First slide">
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100" src="./images/2.jpg" alt="Second slide">
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100" src="./images/3.jpg" alt="Third slide">
                        </div>
                        <div class="carousel-item">
                            <img class="d-block w-100" src="./images/Nen.jpg" alt="Fourth slide">
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
            <div class="container">
                <h5 style="color: red;">Chỉ dẫn:</h5>
                <div class="item">Video hướng dẫn sử dụng thư viện: <a href="#">[chi tiết]</a></div>
                <div class="item">Nội quy thư viện: <a href="#">[chi tiết]</a></div>
                <hr ><div>
                    <p>Số lượt truy cập hôm nay: <?php echo $today_count; ?></p>
                    <p>Số người đang online: <?php echo $online_count; ?></p>
                    <p>Tổng số lượt truy cập: <?php echo $total_count; ?></p>
                </div>
            </div>
        </div>

        <div class="banner">
            <h1>HUBT</h1>
            <p>THƯ VIỆN TRƯỜNG ĐẠI HỌC KINH DOANH VÀ CÔNG NGHỆ HÀ NỘI</p>
            <p>Vĩnh Tuy, Hai Bà Trưng, Hà Nội</p>
            <p>Điện thoại: 1234, Email: hubt.edu.vn</p>
            <div class="social-icons">
                <a href="#" target="">Facebook</a>
                <a href="#" target="">YouTube</a>
            </div>
        </div>

        <footer>
            &copy; 2024 HUBT Library. All rights reserved.
        </footer>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
