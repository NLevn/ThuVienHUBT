<?php
  include "connection.php";
  include "navbar.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Yêu cầu mượn sách</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<style type="text/css">
		.srch {
			padding-left: 1000px;
		}
		
		body {
			font-family: "Lato", sans-serif;
			transition: background-color .5s;
		}

		.sidenav {
			height: 100%;
			margin-top: 50px;
			width: 0;
			position: fixed;
			z-index: 1;
			top: 0;
			left: 0;
			background-color: #222;
			overflow-x: hidden;
			transition: 0.5s;
			padding-top: 60px;
		}

		.sidenav a {
			padding: 8px 8px 8px 32px;
			text-decoration: none;
			font-size: 25px;
			color: #818181;
			display: block;
			transition: 0.3s;
		}

		.sidenav a:hover {
			color: white;
		}

		.sidenav .closebtn {
			position: absolute;
			top: 0;
			right: 25px;
			font-size: 36px;
			margin-left: 50px;
		}

		#main {
			transition: margin-left .5s;
			padding: 16px;
		}

		@media screen and (max-height: 450px) {
			.sidenav {padding-top: 15px;}
			.sidenav a {font-size: 18px;}
		}
		.img-circle {
			margin-left: 20px;
		}
		.h:hover {
			color: white;
			width: 300px;
			height: 50px;
			background-color: #00544c;
		}
	</style>

</head>
<body>
<!--_________________sidenav_______________-->
	
	<div id="mySidenav" class="sidenav">
		<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>

		<div style="color: white; margin-left: 60px; font-size: 20px;">
			<?php
				if(isset($_SESSION['login_user'])) { 	
					echo "<img class='img-circle profile_img' height=120 width=120 src='images/".$_SESSION['pic']."'>";
					echo "</br></br>";
					echo "Welcome ".$_SESSION['login_user']; 
				}
			?>
		</div><br><br>

		<div class="h"><a href="books.php">Sách</a></div>
		<div class="h"><a href="request.php">Yêu cầu mượn sách</a></div>
		<div class="h"><a href="issue_info.php">Thông tin mượn sách</a></div>
	</div>

	<div id="main">
		<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
		<div class="container">
			<script>
				function openNav() {
					document.getElementById("mySidenav").style.width = "300px";
					document.getElementById("main").style.marginLeft = "300px";
					document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
				}

				function closeNav() {
					document.getElementById("mySidenav").style.width = "0";
					document.getElementById("main").style.marginLeft= "0";
					document.body.style.backgroundColor = "white";
				}
			</script>
			<br><br>

			<?php
				$q = mysqli_query($db, "SELECT * from ban_doc where username='$_SESSION[login_user]'");

				if (mysqli_num_rows($q) == 0) {
					echo "<h1>Trang sách của bạn trống!</h1>";
				} else {
					echo "<form action='' method='post'>";
					echo "<table class='table table-bordered table-hover'>";
					echo "<tr style='background-color: #ccc;'>";
					echo "<th>Chọn</th>";
					echo "<th>Mã sách</th>";
					echo "<th>Tên sách</th>";
					echo "</tr>";

					while($row = mysqli_fetch_assoc($q)) {
						echo "<tr>";
						echo "<td><input type='checkbox' name='check[]' value='" . $row['bid'] . "'></td>";
						echo "<td>" . $row['bid'] . "</td>";
						echo "<td>" . $row['name'] . "</td>";
						echo "</tr>";
					}

					echo "</table>";
					echo "<p align='center'><button type='submit' name='delete' class='btn btn-success'>Xóa</button></p>";
					echo "<p align='center'><button type='submit' name='submit1' class='btn btn-success'>Yêu cầu mượn sách</button></p>";
					echo "</form>";
				}
			?>
		</div>
	</div>

	<?php
		if (isset($_POST['delete'])) {
			if (isset($_POST['check'])) {
				foreach ($_POST['check'] as $delete_id) {
					mysqli_query($db, "DELETE from ban_doc where bid='$delete_id' and username='$_SESSION[login_user]' order by bid ASC limit 1;");
				}
			}
		}

		if (isset($_POST['submit1'])) {
			if (isset($_SESSION['login_user'])) {
				if (isset($_POST['check'])) {
					foreach ($_POST['check'] as $bid) {
						$sql_insert = "INSERT INTO issue_book (username, bid, approve, issue, `return`) VALUES ('$_SESSION[login_user]', '$bid', '', '', '')";
						$result_insert = mysqli_query($db, $sql_insert);

						if ($result_insert) {
							$sql_delete = "DELETE FROM ban_doc WHERE bid='$bid' AND username='$_SESSION[login_user]'";
							$result_delete = mysqli_query($db, $sql_delete);

							if ($result_delete) {
								echo "<script>alert('Yêu cầu mượn sách thành công!');</script>";
							} else {
								echo "Lỗi khi xóa sách: " . mysqli_error($db);
							}
						} else {
							echo "Lỗi khi chèn sách: " . mysqli_error($db);
						}
					}
				}
			} else {
				echo "<script>alert('Bạn cần đăng nhập để yêu cầu mượn sách.');</script>";
			}
		}
	?>
</body>
</html>
