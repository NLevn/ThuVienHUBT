<?php 
include "connection.php";
include "navbar.php";

if (isset($_GET['username'])) {
  $username = $_GET['username'];
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Thay đổi mật khẩu</title>
  <style type="text/css">
    body {
      height: 650px;
      background-image: url("images/7.jpg");
      background-repeat: no-repeat;
    }
    .wrapper {
      width: 400px;
      height: 400px;
      margin:100px auto;
      background-color: black;
      opacity: .8;
      color: white;
      padding: 27px 15px;
    }
    .form-control {
      width: 300px;
    }
  </style>
</head>
<body>
  <div class="wrapper">
    <div style="text-align: center;">
      <h1 style="text-align: center; font-size: 35px;font-family: Lucida Console;">Change Your Password</h1>
    </div>
    <div style="padding-left: 30px;">
      <form action="" method="post">
        <input type="text" name="email" class="form-control" placeholder="Email" required=""><br>
        <input type="text" name="password" class="form-control" placeholder="Mật khẩu mới" required=""><br>
        <button class="btn btn-default" type="submit" name="submit">Cập nhật</button>
      </form>
    </div>
    <?php
    if (isset($_POST['submit'])) {
      if (mysqli_query($db, "UPDATE student SET password='$_POST[password]' WHERE username='$username' AND email='$_POST[email]'")) {
        echo "<script>alert('Cập nhật mật khẩu thành công.');</script>";
      }
    }
    ?>
  </div>
</body>
</html>
