<?php
  include "connection.php";
  include "navbar.php";
?>
<!DOCTYPE html>
<html>
<head>
  <title>Yêu cầu mượn sách</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <style type="text/css">

    .srch {
      padding-left: 850px;
    }

    .form-control {
      width: 300px;
      height: 40px;
      background-color: black;
      color: white;
    }

    body {
      background-image: url("images/aa.jpg");
      background-repeat: no-repeat;
      font-family: "Lato", sans-serif;
      transition: background-color .5s;
    }

    .sidenav {
      height: 100%;
      margin-top: 50px;
      width: 0;
      position: fixed;
      z-index: 1;
      top: 0;
      left: 0;
      background-color: #222;
      overflow-x: hidden;
      transition: 0.5s;
      padding-top: 60px;
    }

    .sidenav a {
      padding: 8px 8px 8px 32px;
      text-decoration: none;
      font-size: 25px;
      color: #818181;
      display: block;
      transition: 0.3s;
    }

    .sidenav a:hover {
      color: white;
    }

    .sidenav .closebtn {
      position: absolute;
      top: 0;
      right: 25px;
      font-size: 36px;
      margin-left: 50px;
    }

    #main {
      transition: margin-left .5s;
      padding: 16px;
    }

    @media screen and (max-height: 450px) {
      .sidenav {padding-top: 15px;}
      .sidenav a {font-size: 18px;}
    }

    .img-circle {
      margin-left: 20px;
    }

    .h:hover {
      color:white;
      width: 300px;
      height: 50px;
      background-color: #00544c;
    }

    .container {
      height: 600px;
      background-color: black;
      opacity: .8;
      color: white;
    }

    .scroll {
      width: 100%;
      height: 500px;
      overflow: auto;
    }

    th, td {
      width: 10%;
    }

    .btn-filter {
      margin-bottom: 20px;
    }

  </style>

</head>
<body>

<!--_________________sidenav_______________-->
  
  <div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>

        <div style="color: white; margin-left: 60px; font-size: 20px;">

                <?php
                if(isset($_SESSION['login_user'])) {
                    echo "<img class='img-circle profile_img' height=120 width=120 src='images/".$_SESSION['pic']."'>";
                    echo "</br></br>";
                    echo "Welcome ".$_SESSION['login_user']; 
                }
                ?>
            </div><br><br>

 
  <div class="h"> <a href="books.php">Sách</a></div>
  <div class="h"> <a href="issue_info.php">Thông tin mượn sách</a></div>
</div>

<div id="main">
  
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>

  <script>
  function openNav() {
    document.getElementById("mySidenav").style.width = "300px";
    document.getElementById("main").style.marginLeft = "300px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
  }

  function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
  }
  </script>

  <div class="container">
    <h3 style="text-align: center; color: #222 black;">SÁCH ĐANG MƯỢN</h3><br>
    
    <div class="btn-filter">
      <form method="post" action="">
        <input type="submit" name="overdue" value="Lọc sách đã quá hạn" class="btn btn-warning">
        <input type="submit" name="due_soon" value="Lọc sách gần đến hạn (3 ngày)" class="btn btn-info">
      </form>
    </div>

    <?php
    $c=0;
    $today = date("Y-m-d");

    if(isset($_SESSION['login_user'])) {
        $filter = "";

        if (isset($_POST['overdue'])) {
            $filter = "AND `return` < '$today'";
        } elseif (isset($_POST['due_soon'])) {
            $three_days_later = date("Y-m-d", strtotime("+3 days"));
            $filter = "AND `return` BETWEEN '$today' AND '$three_days_later'";
        }

        $sql="SELECT student.username, roll, books.bid, name, authors, edition, issue, issue_book.return 
              FROM student 
              INNER JOIN issue_book ON student.username = issue_book.username 
              INNER JOIN books ON issue_book.bid = books.bid 
              WHERE issue_book.username = '$_SESSION[login_user]' 
              AND issue_book.approve !='' $filter 
              ORDER BY `issue_book`.`return` ASC";
        $res = mysqli_query($db, $sql);
        
        echo "<table class='table table-bordered' style='width:100%;' >";
        //Table header
        echo "<tr style='background-color: #ccc;'>";
        echo "<th>Tên người dùng</th>";
        echo "<th>SDT</th>";
        echo "<th>Mã sách</th>";
        echo "<th>Tên sách</th>";
        echo "<th>Tác giả</th>";
        echo "<th>Phiên bản</th>";
        echo "<th>Ngày mượn</th>";
        echo "<th>Ngày trả</th>";
        echo "<th>Trạng thái</th>";
        echo "</tr>"; 

        echo "</table>";

        echo "<div class='scroll'>";
        echo "<table class='table table-bordered' >";

        while($row = mysqli_fetch_assoc($res)) {
            $return_date = $row['return'];
            $status = (strtotime($return_date) < strtotime($today)) ? "Quá hạn" : "Đang mượn";

            echo "<tr>";
            echo "<td>{$row['username']}</td>";
            echo "<td>{$row['roll']}</td>";
            echo "<td>{$row['bid']}</td>";
            echo "<td>{$row['name']}</td>";
            echo "<td>{$row['authors']}</td>";
            echo "<td>{$row['edition']}</td>";
            echo "<td>{$row['issue']}</td>";
            echo "<td>{$row['return']}</td>";
            echo "<td>$status</td>";
            echo "</tr>";
        }

        echo "</table>";
        echo "</div>";
       
    } else {
        echo "<h3 style='text-align: center;'>Đăng nhập để xem thông tin mượn sách</h3>";
    }
    ?>
  </div>
</div>
</body>
</html>
