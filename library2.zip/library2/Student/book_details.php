<?php

include '../connection.php'; // Kết nối tới cơ sở dữ liệu
session_start();
include 'navbar.php';
// Kiểm tra xem người dùng đã đăng nhập chưa
if (!isset($_SESSION['login_user'])) {
    header("Location: login.php");
    exit();
}

$user = $_SESSION['login_user'];

// Lấy mã sách từ URL
if (isset($_GET['bid'])) {
    $book_id = mysqli_real_escape_string($db, $_GET['bid']);
    
    // Truy vấn để lấy thông tin sách
    $query = "SELECT * FROM books WHERE bid = '$book_id'";
    $result = mysqli_query($db, $query);

    if (!$result) {
        die("Lỗi truy vấn sách: " . mysqli_error($db));
    }

    $book = mysqli_fetch_assoc($result);

    if ($book) {
        $name = $book['name'];
        $authors = $book['authors'];
        $img = $book['img'];
        $edition = $book['edition'];
        $status = $book['status'];
        $quantity = $book['quantity'];
        $department = $book['department'];
        $introduce = $book['introduce'];
        $soft_copy_url = $book['soft_copy_url'];

        // Xử lý khi nhấn nút "Thêm vào trang bạn đọc"
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_reader'])) {
            $username = $_SESSION['login_user'];
            
            // Lưu sách vào bảng ban_doc
            $insert_query = "INSERT INTO ban_doc (username, bid, name, authors) VALUES ('$username', '$book_id', '$name', '$authors')";
            if (mysqli_query($db, $insert_query)) {
                echo "<script>alert('Đã thêm sách vào trang bạn đọc');</script>";
            } else {
                echo "<script>alert('Lỗi thêm sách vào trang bạn đọc: " . mysqli_error($db) . "');</script>";
            }
        }

    } else {
        echo "<p>Không tìm thấy thông tin sách.</p>";
        exit();
    }
} else {
    echo "<p>Mã sách không được cung cấp.</p>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chi tiết sách</title>
    <style>
        /* Bố trí chung cho trang */
        .container {
            display: flex;
            width: 100%;
            padding: 20px;
            box-sizing: border-box;
        }

        /* Phần chi tiết sách */
        .book-detail {
            display: flex;
            width: 70%;
            padding: 20px;
            box-sizing: border-box;
        }

        .book-image {
            width: 30%;
            padding-right: 20px;
        }

        .book-image img {
            width: 100%; /* Kích thước ảnh sách */
            height: auto;
        }

        .book-info {
            width: 70%;
        }

        /* Phần gợi ý bạn đọc */
        .recommendations {
            width: 30%;
            padding: 20px;
            box-sizing: border-box;
        }

        /* Bố trí cho phần bình luận */
        .comments {
            width: 100%;
            padding: 20px;
            box-sizing: border-box;
        }

        /* Style cho bảng bình luận */
        .table {
            width: 100%;
            border-collapse: collapse;
        }

        .table th, .table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .table th {
            background-color: #f4f4f4;
        }

        /* Style cho form bình luận */
        form {
            margin-top: 20px;
        }

        .form-control {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .btn-default {
            background-color: #007bff;
            color: #fff;
        }

        .recommendations ul {
            list-style: none;
            padding: 0;
        }

        .recommendations li {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }

        .related-book img {
            margin-right: 10px;
            width: 100px; /* Kích thước ảnh sách gợi ý */
            height: auto;
        }

    </style>
</head>
<body>
    <div class="container">
        <!-- Phần chi tiết sách -->
        <div class="book-detail">
            <!-- Phần ảnh sách -->
            <div class="book-image">
                <img src="../Admin/<?php echo htmlspecialchars($img); ?>" alt="Ảnh sách">
            </div>
            <!-- Phần thông tin sách -->
            <div class="book-info">
                <h2>Chi tiết sách</h2>
                <p><strong>Tên sách:</strong> <?php echo htmlspecialchars($name); ?></p>
                <p><strong>Mã sách:</strong> <?php echo htmlspecialchars($book_id); ?></p>
                <p><strong>Tác giả:</strong> <?php echo htmlspecialchars($authors); ?></p>
                <p><strong>Phiên bản:</strong> <?php echo htmlspecialchars($edition); ?></p>
                <p><strong>Thể loại:</strong> <?php echo htmlspecialchars($status); ?></p>
                <p><strong>Số lượng:</strong> <?php echo htmlspecialchars($quantity); ?></p>
                <p><strong>Vị trí:</strong> <?php echo htmlspecialchars($department); ?></p>
                <p><strong>Mô Tả:</strong> <?php echo htmlspecialchars($introduce); ?></p>
                <?php
                $file_path = "../Admin/" . htmlspecialchars($soft_copy_url);

                if (!empty($soft_copy_url) && file_exists($file_path)) {
                    echo "<a href='$file_path' class='btn btn-default'>Đọc bản mềm</a>";
                } else {
                    echo "<p>File bản mềm không tồn tại hoặc không được cung cấp.</p>";
                }
                ?>
                <!-- Nút thêm vào trang bạn đọc -->
                <form action="book_details.php?bid=<?php echo htmlspecialchars($book_id); ?>" method="post">
                    <input type="hidden" name="book_id" value="<?php echo htmlspecialchars($book_id); ?>">
                    <button type="submit" name="add_to_reader" class="btn">Thêm vào trang bạn đọc</button>
                </form>
            </div>
        </div>
        
        <!-- Phần gợi ý bạn đọc -->
        <div class="recommendations">
            <h3>Gợi ý bạn đọc</h3>
            <?php
            $current_book_status = mysqli_real_escape_string($db, $status);
            $keywords = explode(',', $current_book_status);
            $sql_like = [];
            foreach ($keywords as $keyword) {
                $keyword = trim($keyword);
                $sql_like[] = "status LIKE '%" . mysqli_real_escape_string($db, $keyword) . "%'";
            }
            $like_query = implode(' OR ', $sql_like);
            $related_books_query = "SELECT * FROM books WHERE ($like_query) AND bid != '$book_id' LIMIT 3";
            $related_books_result = mysqli_query($db, $related_books_query);

            if (!$related_books_result) {
                die("Lỗi truy vấn sách gợi ý: " . mysqli_error($db));
            }

            if (mysqli_num_rows($related_books_result) > 0) {
                echo "<ul>";
                while ($related_book = mysqli_fetch_assoc($related_books_result)) {
                    ?>
                    <li>
                        <div class="related-book">
                            <a href="book_details.php?bid=<?php echo htmlspecialchars($related_book['bid']); ?>">
                                <img src="../Admin/<?php echo htmlspecialchars($related_book['img']); ?>" alt="Ảnh sách gợi ý">
                                <p><?php echo htmlspecialchars($related_book['name']); ?></p>
                            </a>
                        </div>
                    </li>
                    <?php
                }
                echo "</ul>";
            } else {
                echo "<p>Không có sách gợi ý nào.</p>";
            }
            ?>
        </div>
    </div>

    <!-- Hiển thị bình luận -->
    <!-- Hiển thị bình luận -->
    <div class="comments">
            <h3>Bình luận</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>Người dùng</th>
                        <th>Bình luận</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                if (isset($_POST['submit'])) {
                    $comment = mysqli_real_escape_string($db, $_POST['comment']);
                    $username = mysqli_real_escape_string($db, $_SESSION['login_user']);
                    $book_id = mysqli_real_escape_string($db, $_POST['book_id']);

                    $sql = "INSERT INTO reviews (book_id, username, comment) VALUES ('$book_id', '$username', '$comment')";

                    if (mysqli_query($db, $sql)) {
                        echo "<p class='alert alert-success'>Bình luận đã được gửi.</p>";
                    } else {
                        echo "<p class='alert alert-danger'>Lỗi: " . mysqli_error($db) . "</p>";
                    }
                }

                $sql = "SELECT * FROM reviews WHERE book_id='$book_id' ORDER BY created_at DESC";
                $res = mysqli_query($db, $sql);

                if (mysqli_num_rows($res) > 0) {
                    while ($row = mysqli_fetch_assoc($res)) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['username']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['comment']) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='2'>Chưa có bình luận.</td></tr>";
                }
                ?>
                </tbody>
            </table>
            
            <!-- Form bình luận -->
            <form action="book_details.php?bid=<?php echo htmlspecialchars($book_id); ?>" method="post">
                <input type="hidden" name="book_id" value="<?php echo htmlspecialchars($book_id); ?>">
                <textarea name="comment" class="form-control" rows="4" placeholder="Nhập bình luận của bạn"></textarea>
                <button type="submit" name="submit" class="btn btn-default">Gửi bình luận</button>
            </form>
        </div>
        </body>
        </html>
        <?php
    
?>
    </div>
</body>
</html>
