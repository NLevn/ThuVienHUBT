<?php
include "navbar.php";
include "connection.php";
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chỉnh sửa hồ sơ</title>
    <style>
        body {
            font-family: "Lato", sans-serif;
            background-color: #2ac4c5;
            color: #fff;
            margin: 0;
            padding: 0;
            text-align: center;
        }

        .container {
            max-width: 500px;
            margin: 30px auto;
            padding: 20px;
            background-color: #fff;
            color: #333;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .title {
            color: #333;
            margin-bottom: 20px;
            font-size: 24px;
        }

        .profile-info {
            margin-bottom: 20px;
        }

        .profile-info span {
            display: block;
            font-size: 18px;
            color: #333;
        }

        .profile-info h4 {
            margin-top: 5px;
            font-size: 22px;
            color: #333;
        }

        .form-container {
            text-align: left;
            margin: 0 auto;
            max-width: 500px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-control {
            width: 100%;
            height: 38px;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-control[type="file"] {
            padding: 0;
        }

        .btn {
            background-color: #00544c;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: #003d3a;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="title">Chỉnh sửa thông tin</h2>

        <?php
        $sql = "SELECT * FROM student WHERE username='$_SESSION[login_user]'";
        $result = mysqli_query($db, $sql) or die(mysqli_error($db));

        while ($row = mysqli_fetch_assoc($result)) {
            $first = $row['first'];
            $last = $row['last'];
            $username = $row['username'];
            $password = $row['password'];
            $email = $row['email'];
            $contact = $row['contact'];
            $pic = $row['pic']; // Assuming you have an existing picture
        }
        ?>

        <div class="profile-info">
            <span>Chào mừng,</span>
            <h4><?php echo $_SESSION['login_user']; ?></h4>
        </div>

        <div class="form-container">
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="file">Chọn ảnh:</label>
                    <input class="form-control" type="file" id="file" name="file">
                </div>

                <div class="form-group">
                    <label for="first">Họ:</label>
                    <input class="form-control" type="text" id="first" name="first" value="<?php echo $first; ?>">
                </div>

                <div class="form-group">
                    <label for="last">Tên:</label>
                    <input class="form-control" type="text" id="last" name="last" value="<?php echo $last; ?>">
                </div>

                <div class="form-group">
                    <label for="username">Tên đăng nhập:</label>
                    <input class="form-control" type="text" id="username" name="username" value="<?php echo $username; ?>">
                </div>

                <div class="form-group">
                    <label for="password">Mật khẩu:</label>
                    <input class="form-control" type="password" id="password" name="password" value="<?php echo $password; ?>">
                </div>

                <div class="form-group">
                    <label for="email">Email:</label>
                    <input class="form-control" type="email" id="email" name="email" value="<?php echo $email; ?>">
                </div>

                <div class="form-group">
                    <label for="contact">Số điện thoại:</label>
                    <input class="form-control" type="text" id="contact" name="contact" value="<?php echo $contact; ?>">
                </div>

                <div class="form-group">
                    <button class="btn" type="submit" name="submit">Lưu</button>
                </div>
            </form>
        </div>

        <?php
        if(isset($_POST['submit'])) {
            move_uploaded_file($_FILES['file']['tmp_name'], "images/".$_FILES['file']['name']);

            $first = $_POST['first'];
            $last = $_POST['last'];
            $username = $_POST['username'];
            $password = $_POST['password'];
            $email = $_POST['email'];
            $contact = $_POST['contact'];
            $pic = $_FILES['file']['name'];

            $sql1 = "UPDATE student SET pic='$pic', first='$first', last='$last', username='$username', password='$password', email='$email', contact='$contact' WHERE username='".$_SESSION['login_user']."';";

            if(mysqli_query($db,$sql1)) {
                ?>
                <script type="text/javascript">
                    alert("Lưu thành công.");
                    window.location="profile.php";
                </script>
                <?php
            }
        }
        ?>
    </div>
</body>
</html>
