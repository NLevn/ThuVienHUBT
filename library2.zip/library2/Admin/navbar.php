<?php
  if (session_status() == PHP_SESSION_NONE) {
      session_start();
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>
<body>
<?php
  include "connection.php";

  if (isset($_SESSION['login_user'])) {
    // Lấy số lượng tin nhắn chưa đọc từ quản trị viên
    $r = mysqli_query($db, "SELECT COUNT(status) as total FROM message WHERE status='no' AND username='" . mysqli_real_escape_string($db, $_SESSION['login_user']) . "' AND sender='admin'");
    $c = mysqli_fetch_assoc($r);

    // Lấy số lượng yêu cầu từ quản trị viên
    $sql_app = mysqli_query($db, "SELECT COUNT(status) as total FROM admin WHERE status=''");
    $a = mysqli_fetch_assoc($sql_app);
  }
?>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand active">HỆ THỐNG QUẢN LÝ THƯ VIỆN TRỰC TUYẾN</a>
    </div>
    <ul class="nav navbar-nav">
      
      <li><a href="books.php">SÁCH</a></li>
      <li><a href="feedback.php">PHẢN HỒI</a></li>
    </ul>
    <?php
      if (isset($_SESSION['login_user'])) {
    ?>
    <ul class="nav navbar-nav">
      <li><a href="profile.php">HỒ SƠ</a></li>
      <li><a href="student.php">THÔNG TIN SINH VIÊN</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="admin_status.php"><span class="glyphicon glyphicon-user"></span> &nbsp <span class="badge bg-green"><?php echo $a['total']; ?></span></a></li>
      <!-- <li><a href="message.php"><span class="glyphicon glyphicon-envelope"></span> &nbsp <span class="badge bg-green"><?php echo $c['total']; ?></span></a></li> -->
      <li>
        <div style="color: white ; margin-top: 10px;">
          <?php
            echo "<img class='img-circle profile_img' height=30 width=30 src='images/ " . htmlspecialchars($_SESSION['pic']) . "'>";
            echo " " . htmlspecialchars($_SESSION['login_user']);
          ?>
        </div>
      </li>
      <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"> ĐĂNG XUẤT</span></a></li>
    </ul>
    <?php
      } else {
    ?>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="../login.php"><span class="glyphicon glyphicon-log-in"> ĐĂNG NHẬP</span></a></li>
      <li><a href="registration.php"><span class="glyphicon glyphicon-user"> ĐĂNG KÝ</span></a></li>
    </ul>
    <?php
      }
    ?>
  </div>
</nav>
</body>
</html>
