<?php
// Kết nối cơ sở dữ liệu
include "connection.php";
include "navbar.php";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Thêm Sách Mới</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style type="text/css">
        .srch {
            padding-left: 1000px;
        }

        body {
            background-color: #818181;
            font-family: "Lato", sans-serif;
            transition: background-color .5s;
        }

        .sidenav {
            height: 100%;
            margin-top: 50px;
            width: 0;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #222;
            overflow-x: hidden;
            transition: 0.5s;
            padding-top: 60px;
        }

        .sidenav a {
            padding: 8px 8px 8px 32px;
            text-decoration: none;
            font-size: 25px;
            color: #818181;
            display: block;
            transition: 0.3s;
        }

        .sidenav a:hover {
            color: white;
        }

        .sidenav .closebtn {
            position: absolute;
            top: 0;
            right: 25px;
            font-size: 36px;
            margin-left: 50px;
        }

        #main {
            transition: margin-left .5s;
            padding: 16px;
        }

        @media screen and (max-height: 450px) {
            .sidenav {padding-top: 15px;}
            .sidenav a {font-size: 18px;}
        }

        .img-circle {
            margin-left: 20px;
        }

        .h:hover {
            color: white;
            width: 300px;
            height: 50px;
            background-color: #00544c;
        }

        .book {
            width: 400px;
            margin: 0px auto;
        }

        .form-control {
            background-color: #080707;
            color: white;
            height: 40px;
        }

        .container {
            text-align: center;
        }
    </style>
</head>
<body>
    <!--_________________sidenav_______________-->
    
    <!-- Nội dung trang web của bạn -->

    <div id="main">
        <span style="font-size:30px;cursor:pointer; color: black;" onclick="openNav()">&#9776; </span>
        <div class="container">
            <h2 style="color:black; font-family: Arial, Helvetica, sans-serif; text-align: center"><b>Thêm sách mới</b></h2>
            
            <form class="book" action="" method="post" enctype="multipart/form-data">
                <input type="file" name="img" class="form-control" placeholder="Ảnh" required=""><br>
                <input type="text" name="bid" class="form-control" placeholder="Mã sách" required=""><br>
                <input type="text" name="name" class="form-control" placeholder="Tên sách" required=""><br>
                <input type="text" name="authors" class="form-control" placeholder="Tác giả" required=""><br>
                <input type="text" name="edition" class="form-control" placeholder="Phiên bản" required=""><br>
                <input type="text" name="status" class="form-control" placeholder="Thể loại" required=""><br>
                <input type="text" name="quantity" class="form-control" placeholder="Số lượng" required=""><br>
                <input type="text" name="department" class="form-control" placeholder="Vị trí" required=""><br>
                <input type="text" name="introduce" class="form-control" placeholder="Giới thiệu" required=""><br>
                <input type="file" name="soft" class="form-control" placeholder="Bản mềm" required=""><br>
                <button style="text-align: center;" class="btn btn-default" type="submit" name="submit">Thêm</button>
            </form>
        </div>

        <?php
            if (isset($_POST['submit'])) {
                if (isset($_SESSION['login_user'])) {
                    // Đường dẫn thư mục lưu ảnh
                    $img_target_dir = "images/";
                    $img_target_file = $img_target_dir . basename($_FILES["img"]["name"]);

                    // Đường dẫn thư mục lưu bản mềm
                    $soft_target_dir = "softcopies/";
                    $soft_target_file = $soft_target_dir . basename($_FILES["soft"]["name"]);

                    // Kiểm tra và tạo thư mục nếu không tồn tại
                    if (!is_dir($soft_target_dir)) {
                        mkdir($soft_target_dir, 0777, true);
                    }

                    // Kiểm tra nếu file thực sự là ảnh
                    $check_img = getimagesize($_FILES["img"]["tmp_name"]);
                    if ($check_img !== false) {
                        // Lưu ảnh vào thư mục
                        if (move_uploaded_file($_FILES["img"]["tmp_name"], $img_target_file)) {
                            // Lưu bản mềm vào thư mục
                            if (move_uploaded_file($_FILES["soft"]["tmp_name"], $soft_target_file)) {
                                // Kiểm tra xem mã sách đã tồn tại hay chưa
                                $bid = $_POST['bid'];
                                $check_bid_query = "SELECT * FROM books WHERE bid = '$bid'";
                                $check_bid_result = mysqli_query($db, $check_bid_query);

                                if (mysqli_num_rows($check_bid_result) > 0) {
                                    echo "<script>alert('Mã sách đã tồn tại. Vui lòng chọn mã khác.');</script>";
                                } else {
                                    // Thêm sách mới vào cơ sở dữ liệu
                                    $query = "INSERT INTO books (img, bid, name, authors, edition, status, quantity, department, introduce, soft_copy_url)
                                              VALUES ('$img_target_file', '$bid', '$_POST[name]', '$_POST[authors]', '$_POST[edition]', '$_POST[status]', '$_POST[quantity]', '$_POST[department]', '$_POST[introduce]', '$soft_target_file')";

                                    if (mysqli_query($db, $query)) {
                                        echo "<script>alert('Thêm sách thành công.');</script>";
                                    } else {
                                        echo "<script>alert('Lỗi: " . mysqli_error($db) . "');</script>";
                                    }
                                }
                            } else {
                                echo "<script>alert('Không thể tải bản mềm lên.');</script>";
                            }
                        } else {
                            echo "<script>alert('Không thể tải ảnh lên.');</script>";
                        }
                    } else {
                        echo "<script>alert('Tệp ảnh không hợp lệ.');</script>";
                    }
                } else {
                    echo "<script>alert('Bạn cần đăng nhập để thực hiện.');</script>";
                }
            }
        ?>
    </div>

    <script>
        function openNav() {
            document.getElementById("mySidenav").style.width = "300px";
            document.getElementById("main").style.marginLeft = "300px";
            document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
        }

        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
            document.getElementById("main").style.marginLeft= "0";
            document.body.style.backgroundColor = "#024629";
        }
    </script>

</body>
</html>
