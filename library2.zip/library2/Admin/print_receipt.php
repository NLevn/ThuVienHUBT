<?php
// Kết nối cơ sở dữ liệu và bắt đầu phiên làm việc
include "connection.php";
session_start();

// Kiểm tra nếu thông tin người dùng và mã sách đã được lưu trong session
if (isset($_SESSION['name']) && isset($_SESSION['bid'])) {
    $username = $_SESSION['name'];
    $bid = $_SESSION['bid'];

    // Truy vấn lấy thông tin sách và người mượn
    $sql = "SELECT student.username, student.roll, books.bid, books.name, books.authors, books.edition, 
                   issue_book.issue_date, issue_book.return_date
            FROM student 
            INNER JOIN issue_book ON student.username = issue_book.username 
            INNER JOIN books ON issue_book.bid = books.bid 
            WHERE issue_book.username = '$username' AND issue_book.bid = '$bid'";

    $result = mysqli_query($db, $sql);
    $data = mysqli_fetch_assoc($result);

    // Kiểm tra nếu tìm thấy dữ liệu
    if ($data) {
        ?>
        <!DOCTYPE html>
        <html lang="vi">
        <head>
            <meta charset="UTF-8">
            <title>In Phiếu Mượn Sách</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    margin: 20px;
                }
                .receipt-container {
                    width: 600px;
                    margin: auto;
                    padding: 20px;
                    border: 1px solid #333;
                    border-radius: 8px;
                    background-color: #f4f4f4;
                }
                h2 {
                    text-align: center;
                    color: #333;
                }
                .receipt-content {
                    font-size: 16px;
                    line-height: 1.6;
                    margin: 10px 0;
                }
                .print-button {
                    text-align: center;
                    margin-top: 20px;
                }
                .print-button button {
                    padding: 10px 20px;
                    font-size: 16px;
                    background-color: #333;
                    color: #fff;
                    border: none;
                    cursor: pointer;
                    border-radius: 4px;
                }
                .print-button button:hover {
                    background-color: #555;
                }
            </style>
        </head>
        <body>

        <div class="receipt-container">
            <h2>Phiếu Mượn Sách</h2>
            <div class="receipt-content">
                <p><strong>Tên người mượn:</strong> <?php echo htmlspecialchars($data['username']); ?></p>
                <p><strong>Số thẻ:</strong> <?php echo htmlspecialchars($data['roll']); ?></p>
                <p><strong>Mã sách:</strong> <?php echo htmlspecialchars($data['bid']); ?></p>
                <p><strong>Tên sách:</strong> <?php echo htmlspecialchars($data['name']); ?></p>
                <p><strong>Tác giả:</strong> <?php echo htmlspecialchars($data['authors']); ?></p>
                <p><strong>Phiên bản:</strong> <?php echo htmlspecialchars($data['edition']); ?></p>
                <p><strong>Ngày mượn:</strong> <?php echo htmlspecialchars($data['issue_date']); ?></p>
                <p><strong>Ngày trả:</strong> <?php echo htmlspecialchars($data['return_date']); ?></p>
            </div>
            <div class="print-button">
                <button onclick="window.print()">In Phiếu</button>
            </div>
        </div>

        </body>
        </html>
        <?php
    } else {
        echo "<h2>Không tìm thấy dữ liệu để in phiếu.</h2>";
    }
} else {
    echo "<h2>Không có thông tin hợp lệ để in phiếu. Vui lòng quay lại và thử lại.</h2>";
}
?>
