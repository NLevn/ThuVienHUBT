<?php
session_start();
include "connection.php";
include "navbar.php";
?>
<!DOCTYPE html>
<html>
<head>
  <title>Sách Quá Hạn</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style type="text/css">
    /* Style here */
  </style>
</head>
<body>
<!--_________________sidenav_______________-->
  <div id="mySidenav" class="sidenav">
    <!-- Sidebar code here -->
  </div>
  <div id="main">
    <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>
    <script>
      function openNav() {
        document.getElementById("mySidenav").style.width = "300px";
        document.getElementById("main").style.marginLeft = "300px";
        document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
      }
      function closeNav() {
        document.getElementById("mySidenav").style.width = "0";
        document.getElementById("main").style.marginLeft= "0";
        document.body.style.backgroundColor = "white";
      }
    </script>

    <div class="container">
      <h3 style="text-align: center; color: black;">Danh Sách Sách Quá Hạn</h3><br>
      <div style="float: left; padding: 25px;">
        <form method="post" action="">
          <button name="submit2" type="submit" class="btn btn-default" style="background-color: #06861a; color: yellow;">ĐÃ TRẢ</button> 
          &nbsp&nbsp
          <button name="submit3" type="submit" class="btn btn-default" style="background-color: red; color: yellow;">CHƯA TRẢ</button>
        </form> 
      </div>

      <?php
      if(isset($_POST['submit'])) {
          $res = mysqli_query($db, "SELECT * FROM `issue_book` WHERE username='$_POST[username]' AND bid='$_POST[bid]';");

          while($row = mysqli_fetch_assoc($res)) {
              $return_date = strtotime($row['return']);
              $current_date = strtotime(date("Y-m-d"));
              
              // Nếu ngày hiện tại đã qua ngày trả sách, tính tiền phạt
              if ($current_date > $return_date) {
                  $days_overdue = floor(($current_date - $return_date) / (60 * 60 * 24));
                  $fine = $days_overdue * 0.10;
              } else {
                  $days_overdue = 0;
                  $fine = 0;
              }
          }

          $today_date = date("Y-m-d"); 
          mysqli_query($db, "INSERT INTO `fine` (username, bid, date, days_overdue, fine_amount, status) VALUES ('$_POST[username]', '$_POST[bid]', '$today_date', '$days_overdue', '$fine', 'not paid');");

          $update_status = '<p style="color:yellow; background-color:green;">ĐÃ TRẢ</p>';
          mysqli_query($db, "UPDATE issue_book SET approve='$update_status' WHERE username='$_POST[username]' AND bid='$_POST[bid]';");
          mysqli_query($db, "UPDATE books SET quantity = quantity + 1 WHERE bid='$_POST[bid]';");
      }

      if(isset($_POST['submit2'])) {
          $sql = "SELECT student.username, roll, books.bid, name, authors, edition, issue_book.approve, issue, issue_book.return 
                  FROM student 
                  INNER JOIN issue_book ON student.username=issue_book.username 
                  INNER JOIN books ON issue_book.bid=books.bid 
                  WHERE issue_book.approve ='ĐÃ TRẢ' 
                  ORDER BY STR_TO_DATE(issue_book.return, '%d/%m/%Y') DESC";
          $res = mysqli_query($db, $sql);
      } else if(isset($_POST['submit3'])) {
          $sql = "SELECT student.username, roll, books.bid, name, authors, edition, issue_book.approve, issue, issue_book.return 
                  FROM student 
                  INNER JOIN issue_book ON student.username=issue_book.username 
                  INNER JOIN books ON issue_book.bid=books.bid 
                  WHERE issue_book.approve ='CHƯA TRẢ' 
                  ORDER BY STR_TO_DATE(issue_book.return, '%d/%m/%Y') DESC";
          $res = mysqli_query($db, $sql);
      } else {
          $sql = "SELECT student.username, roll, books.bid, name, authors, edition, issue_book.approve, issue, issue_book.return 
                  FROM student 
                  INNER JOIN issue_book ON student.username=issue_book.username 
                  INNER JOIN books ON issue_book.bid=books.bid 
                  WHERE issue_book.approve !='' AND issue_book.approve !='Yes' 
                  ORDER BY STR_TO_DATE(issue_book.return, '%d/%m/%Y') DESC";
          $res = mysqli_query($db, $sql);
      }

      if(isset($_SESSION['login_user'])) {
          $today_date = date("Y-m-d");

          // Truy vấn lấy thông tin sách đã đến hạn trả và chưa trả
          $sql = "SELECT student.username, roll, books.bid, name, authors, edition, issue_book.approve, issue, STR_TO_DATE(issue_book.return, '%d/%m/%Y') AS return_date
                  FROM student 
                  INNER JOIN issue_book ON student.username=issue_book.username 
                  INNER JOIN books ON issue_book.bid=books.bid 
                  WHERE issue_book.approve='Yes' AND STR_TO_DATE(issue_book.return, '%d/%m/%Y') < '$today_date'";

          $res = mysqli_query($db, $sql);

          if (!$res) {
              die("Query failed: " . mysqli_error($db));
          }

          // Hiển thị bảng dữ liệu
          echo "<table class='table table-bordered' style='width:100%;'>";
          echo "<tr style='background-color: #ccc;'>";
          echo "<th>Người Dùng</th>";
          echo "<th>Số Điện Thoại</th>";
          echo "<th>Mã Sách</th>";
          echo "<th>Tên Sách</th>";
          echo "<th>Tên Tác giả</th>";
          echo "<th>Phiên Bản</th>";
          echo "<th>Trạng thái</th>";
          echo "<th>Ngày Mượn</th>";
          echo "<th>Ngày Trả</th>";
          echo "</tr>";
          echo "</table>";

          echo "<div class='scroll'>";
          echo "<table class='table table-bordered'>";
          while($row = mysqli_fetch_assoc($res)) {
              echo "<tr>";
              echo "<td>"; echo htmlspecialchars($row['username']); echo "</td>";
              echo "<td>"; echo htmlspecialchars($row['roll']); echo "</td>";
              echo "<td>"; echo htmlspecialchars($row['bid']); echo "</td>";
              echo "<td>"; echo htmlspecialchars($row['name']); echo "</td>";
              echo "<td>"; echo htmlspecialchars($row['authors']); echo "</td>";
              echo "<td>"; echo htmlspecialchars($row['edition']); echo "</td>";
              echo "<td>"; echo isset($row['approve']) ? htmlspecialchars($row['approve']) : 'N/A'; echo "</td>";
              echo "<td>"; echo htmlspecialchars($row['issue']); echo "</td>";
              echo "<td>"; echo date('d/m/Y', strtotime($row['return_date'])); echo "</td>";
              echo "</tr>";
          }
          echo "</table>";
          echo "</div>";
      }
      ?>
    </div>
  </div>
</body>
</html>
