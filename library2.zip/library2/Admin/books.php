<?php
include "connection.php";
include "navbar.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang sách</title>
    <style type="text/css">
          .srch {
            margin: 20px 0;
            text-align: right;
        }

        body {
            font-family: "Lato", sans-serif;
            margin: 0;
            box-sizing: border-box;
        }

        .table-container {
            margin: 0 auto;
            width: calc(100% - 40px);
            max-width: 1200px;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .table th, .table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .table th {
            background-color: #ccc;
        }

        .table tr:hover {
            background-color: #f5f5f5;
        }

        .table a {
            color: #007bff;
            text-decoration: none;
        }

        .table a:hover {
            text-decoration: underline;
        }

        @media screen and (max-width: 600px) {
            .srch {
                text-align: center;
            }
        }

        .sidenav {
            height: 100%;
            margin-top: 50px;
            width: 0;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #222;
            overflow-x: hidden;
            transition: 0.5s;
            padding-top: 60px;
        }

        .sidenav a {
            padding: 8px 8px 8px 32px;
            text-decoration: none;
            font-size: 25px;
            color: #818181;
            display: block;
            transition: 0.3s;
        }

        .sidenav a:hover {
            color: white;
        }

        .sidenav .closebtn {
            position: absolute;
            top: 0;
            right: 25px;
            font-size: 36px;
            margin-left: 50px;
        }

        #main {
            transition: margin-left .5s;
            padding: 16px;
        }

        @media screen and (max-height: 450px) {
            .sidenav {padding-top: 15px;}
            .sidenav a {font-size: 18px;}
        }

        .img-circle {
            margin-left: 20px;
        }

        .h:hover {
            color: white;
            width: 300px;
            height: 50px;
            background-color: #00544c;
        }
    </style>
</head>
<body>

<!--_________________sidenav_______________-->

<div id="mySidenav" class="sidenav">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>

    <div style="color: white; margin-left: 60px; font-size: 20px;">
        <?php
        if (isset($_SESSION['login_user'])) {
            echo "<img class='img-circle profile_img' height=120 width=120 src='images/" . $_SESSION['pic'] . "'>";
            echo "</br></br>";
            echo "Welcome " . $_SESSION['login_user'];
        }
        ?>
    </div><br><br>

    <div class="h"> <a href="add.php">Thêm sách</a> </div> 
    <div class="h"> <a href="request.php">Yêu cầu mượn sách</a></div>
    <div class="h"> <a href="issue_info.php">Thông tin mượn sách</a></div>
    <div class="h"><a href="expired.php">Danh sách đã trả</a></div>
    <div class="h"><a href="SachQuaHan.php">Sách quá hạn</a></div>
</div>

<div id="main">
    <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>

    <script>
        function openNav() {
            document.getElementById("mySidenav").style.width = "300px";
            document.getElementById("main").style.marginLeft = "300px";
            document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
        }

        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
            document.getElementById("main").style.marginLeft = "0";
            document.body.style.backgroundColor = "white";
        }
    </script>

    <!--___________________search bar________________________-->

    <div class="srch">
        <!-- Tìm kiếm theo tên sách -->
        <form class="navbar-form" method="post" name="search_form">
            <input class="form-control" type="text" name="search" placeholder="Tìm sách.." required="">
            <button style="background-color: #6db6b9e6;" type="submit" name="search_submit" class="btn btn-default">
                Tìm kiếm
            </button>
        </form>
        <!-- Xóa sách theo mã sách -->
        <form class="navbar-form" method="post" name="delete_form">
            <input class="form-control" type="text" name="bid" placeholder="Nhập mã sách muốn xóa" required="">
            <button style="background-color: #6db6b9e6;" type="submit" name="delete_submit" class="btn btn-default">Xóa</button>
        </form>
    </div>

    <!-- Lọc sách theo mã -->
    <div class="srch">
        <form class="navbar-form" method="post" name="filter_form">
            <label for="filter">Lọc theo mã sách:</label>
            <select name="filter" class="form-control">
                <option value="all">Tất cả</option>
                <option value="11">Sách công nghệ</option>
                <option value="12">Sách ngôn ngữ Trung</option>
                <option value="13">Sách ngôn ngữ Nga</option>
            </select>
            <button style="background-color: #6db6b9e6;" type="submit" name="filter_submit" class="btn btn-default">Lọc</button>
        </form>
    </div>

    <div class="table-container">
        <h2>Sách</h2>
        <?php
        // Xử lý tìm kiếm sách
        if (isset($_POST['search_submit'])) {
            $search = mysqli_real_escape_string($db, $_POST['search']);
            $sql = "SELECT * FROM books WHERE name LIKE '%$search%'";
            $result = mysqli_query($db, $sql);

            if (mysqli_num_rows($result) == 0) {
                echo "Không tìm thấy sách với tên '$search'.";
            } else {
                echo "<table class='table'>";
                echo "<tr><th>Ảnh</th><th>Tên sách</th><th>Mã sách</th><th>Tác giả</th><th>Phiên bản</th><th>Thể loại</th><th>Số lượng</th><th>Vị trí</th></tr>";
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td><img src='" . $row['img'] . "' alt='Ảnh sách' style='width:100px; height:auto;'></td>";
                    echo "<td><a href='book_details.php?bid={$row['bid']}'>{$row['name']}</a></td>";
                    echo "<td>{$row['bid']}</td>";
                    echo "<td>{$row['authors']}</td>";
                    echo "<td>{$row['edition']}</td>";
                    echo "<td>{$row['status']}</td>";
                    echo "<td>{$row['quantity']}</td>";
                    echo "<td>{$row['department']}</td>";
                    echo "</tr>";
                }
                echo "</table>";
            }
        } 

        // Xử lý xóa sách
        if (isset($_POST['delete_submit'])) {
            $bid = mysqli_real_escape_string($db, $_POST['bid']);
            $sql = "DELETE FROM books WHERE bid = '$bid'";
            if (mysqli_query($db, $sql)) {
                echo "Sách với mã '$bid' đã được xóa thành công.";
            } else {
                echo "Lỗi khi xóa sách: " . mysqli_error($db);
            }
        }

        // Xử lý lọc sách
        if (isset($_POST['filter_submit'])) {
            $filter = $_POST['filter'];

            if ($filter == '11') {
                $sql = "SELECT * FROM books WHERE bid LIKE '11%'";
            } elseif ($filter == '12') {
                $sql = "SELECT * FROM books WHERE bid LIKE '12%'";
            } elseif ($filter == '13') {
                $sql = "SELECT * FROM books WHERE bid LIKE '13%'";
            } else {
                $sql = "SELECT * FROM books"; // Nếu chọn "Tất cả" thì hiển thị toàn bộ sách
            }

            $result = mysqli_query($db, $sql);

            if (mysqli_num_rows($result) == 0) {
                echo "Không tìm thấy sách phù hợp với tiêu chí lọc.";
            } else {
                echo "<table class='table'>";
                echo "<tr><th>Ảnh</th><th>Tên sách</th><th>Mã sách</th><th>Tác giả</th><th>Phiên bản</th><th>Thể loại</th><th>Số lượng</th><th>Vị trí</th></tr>";
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td><img src='" . $row['img'] . "' alt='Ảnh sách' style='width:100px; height:auto;'></td>";
                    echo "<td><a href='book_details.php?bid={$row['bid']}'>{$row['name']}</a></td>";
                    echo "<td>{$row['bid']}</td>";
                    echo "<td>{$row['authors']}</td>";
                    echo "<td>{$row['edition']}</td>";
                    echo "<td>{$row['status']}</td>";
                    echo "<td>{$row['quantity']}</td>";
                    echo "<td>{$row['department']}</td>";
                    echo "</tr>";
                }
                echo "</table>";
            }
        }

        // Hiển thị toàn bộ sách khi chưa lọc và không có tìm kiếm
        if (!isset($_POST['search_submit']) && !isset($_POST['filter_submit']) && !isset($_POST['delete_submit'])) {
            $res = mysqli_query($db, "SELECT * FROM books ORDER BY name ASC");
            echo "<table class='table'>";
            echo "<tr><th>Ảnh</th><th>Tên sách</th><th>Mã sách</th><th>Tác giả</th><th>Phiên bản</th><th>Thể loại</th><th>Số lượng</th><th>Vị trí</th></tr>";
            while ($row = mysqli_fetch_assoc($res)) {
                echo "<tr>";
                echo "<td><img src='" . $row['img'] . "' alt='Ảnh sách' style='width:100px; height:auto;'></td>";
                echo "<td><a href='book_details.php?bid={$row['bid']}'>{$row['name']}</a></td>";
                echo "<td>{$row['bid']}</td>";
                echo "<td>{$row['authors']}</td>";
                echo "<td>{$row['edition']}</td>";
                echo "<td>{$row['status']}</td>";
                echo "<td>{$row['quantity']}</td>";
                echo "<td>{$row['department']}</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
        ?>
    </div>
</div>
</body>
</html>
