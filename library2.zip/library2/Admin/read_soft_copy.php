<?php
include "connection.php"; // Kết nối cơ sở dữ liệu

if (isset($_GET['bid'])) {
    $book_id = mysqli_real_escape_string($db, $_GET['bid']);
    $q = mysqli_query($db, "SELECT soft_copy_url FROM books WHERE bid='$book_id'");
    $book = mysqli_fetch_assoc($q);

    if ($book && !empty($book['soft_copy_url'])) {
        // Hiển thị file bản mềm
        $soft_copy_url = htmlspecialchars($book['soft_copy_url']);
        
        // Kiểm tra xem soft_copy_url có chứa phần admin/softcopies không
        echo "Soft copy URL: " . $soft_copy_url; // In ra để kiểm tra

        // Nếu soft_copy_url đã bao gồm đường dẫn đầy đủ, không thêm 'admin/softcopies/'
        if (strpos($soft_copy_url, 'Admin/softcopies/') === false) {
            $full_path = $soft_copy_url;
        } else {
            $full_path = $soft_copy_url; // Đường dẫn đã đầy đủ
        }

        // Kiểm tra tệp có tồn tại hay không
        echo "Full Path: " . $full_path; // Kiểm tra đường dẫn đầy đủ
        
        // Xem tệp có tồn tại không
        if (file_exists($full_path)) {
            ?>
            <!DOCTYPE html>
            <html lang="vi">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Đọc bản mềm</title>
            </head>
            <body>
                <h1>Đọc bản mềm</h1>
                <a href="<?php echo $full_path; ?>" target="_blank" class="btn btn-default">Đọc bản mềm</a>
            </body>
            </html>
            <?php
        } else {
            echo "<p>Không tìm thấy bản mềm tại đường dẫn: $full_path</p>";
        }
    } else {
        echo "<p>Không tìm thấy bản mềm.</p>";
    }
} else {
    echo "<p>Không có sách nào được chọn.</p>";
}
?>
