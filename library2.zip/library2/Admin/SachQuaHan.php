<?php
session_start();
include "connection.php";
include "navbar.php";
?>
<!DOCTYPE html>
<html>
<head>
  <title>Quản lý Mượn Trả Sách Quá Hạn</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style type="text/css">
    .sidenav {
            height: 100%;
            margin-top: 50px;
            width: 0;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: #222;
            overflow-x: hidden;
            transition: 0.5s;
            padding-top: 60px;
        }

        .sidenav a {
            padding: 8px 8px 8px 32px;
            text-decoration: none;
            font-size: 25px;
            color: #818181;
            display: block;
            transition: 0.3s;
        }

        .sidenav a:hover {
            color: white;
        }

        .sidenav .closebtn {
            position: absolute;
            top: 0;
            right: 25px;
            font-size: 36px;
            margin-left: 50px;
        }

        #main {
            transition: margin-left .5s;
            padding: 16px;
        }

        @media screen and (max-height: 450px) {
            .sidenav {padding-top: 15px;}
            .sidenav a {font-size: 18px;}
        }

        .img-circle {
            margin-left: 20px;
        }

        .h:hover {
            color: white;
            width: 300px;
            height: 50px;
            background-color: #00544c;
        }
  </style>
  <script>
        function hienThiNgayThang() {
            var ngayHienTai = new Date();
            var ngay = ngayHienTai.getDate();
            var thang = ngayHienTai.getMonth() + 1;
            var nam = ngayHienTai.getFullYear();
            
            if (ngay < 10) ngay = '0' + ngay;
            if (thang < 10) thang = '0' + thang;

            var ngayThangNam = ngay + '/' + thang + '/' + nam;
            document.getElementById("ngay-thang").innerHTML = ngayThangNam;
        }
    </script>
</head>
<body onload="hienThiNgayThang()">
<p id="ngay-thang"></p>
<!--_________________sidenav_______________-->

<div id="mySidenav" class="sidenav">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>

    <div style="color: white; margin-left: 60px; font-size: 20px;">
        <?php
        if (isset($_SESSION['login_user'])) {
            echo "<img class='img-circle profile_img' height=120 width=120 src='images/" . $_SESSION['pic'] . "'>";
            echo "</br></br>";
            echo "Welcome " . $_SESSION['login_user'];
        }
        ?>
    </div><br><br>

    <div class="h"> <a href="add.php">Thêm sách</a> </div> 
    <div class="h"> <a href="request.php">Yêu cầu mượn sách</a></div>
    <div class="h"> <a href="issue_info.php">Thông tin mượn sách</a></div>
    <div class="h"><a href="expired.php">Danh sách đã trả</a></div>
    <div class="h"><a href="SachQuaHan.php">Sách quá hạn</a></div>
</div>

<div id="main">
    <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>

    <script>
        function openNav() {
            document.getElementById("mySidenav").style.width = "300px";
            document.getElementById("main").style.marginLeft = "300px";
            document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
        }

        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
            document.getElementById("main").style.marginLeft = "0";
            document.body.style.backgroundColor = "white";
        }
    </script>
<div class="container">
  <h3 style="text-align: center;color: black;">Sách Quá Hạn</h3><br>

  <!-- Tìm kiếm người dùng với sách quá hạn -->
  <form method="post" action="">
    <input type="text" name="search" class="form-control" placeholder="Tìm kiếm theo tên sách hoặc người dùng...">
    <button type="submit" name="search_button" class="btn btn-default">Tìm kiếm</button>
  </form>
  <br>

  <?php
  $ngayHienTai = date("Y-m-d");

  // Truy vấn SQL để lấy sách quá hạn
  $query = "SELECT student.username, roll, books.bid, name, authors, edition, issue, issue_book.return, issue_book.status, issue_book.return_date 
  FROM student 
  INNER JOIN issue_book ON student.username=issue_book.username 
  INNER JOIN books ON issue_book.bid=books.bid 
  WHERE issue_book.approve='Yes' 
  AND issue_book.status = 0 
  AND STR_TO_DATE(issue_book.return, '%d/%m/%Y') < STR_TO_DATE('$ngayHienTai', '%Y-%m-%d')";

  // Nếu có tìm kiếm
  if (isset($_POST['search_button'])) {
    $search = mysqli_real_escape_string($db, $_POST['search']);
    $query .= " AND (student.username LIKE '%$search%' OR books.name LIKE '%$search%')";
  }

  $res = mysqli_query($db, $query);
  if (!$res) {
    die("Lỗi truy vấn SQL: " . mysqli_error($db));
  } else {
    echo "<table class='table table-bordered'>";
    echo "<tr style='background-color: #ccc;'>";
    echo "<th>Người Dùng</th>";
    echo "<th>Số Điện Thoại</th>";
    echo "<th>Mã Sách</th>";
    echo "<th>Tên Sách</th>";
    echo "<th>Tác Giả</th>";
    echo "<th>Phiên Bản</th>";
    echo "<th>Ngày Mượn</th>";
    echo "<th>Ngày Trả</th>";
    echo "<th>Trạng Thái</th>";
    echo "<th>Chú Thích Ngày Trả</th>";
    echo "<th>Hành Động</th>";
    echo "</tr>";

    while ($row = mysqli_fetch_assoc($res)) {
      echo "<form method='post' action=''>";
      echo "<tr>";
      echo "<td>" . $row['username'] . "</td>";
      echo "<td>" . $row['roll'] . "</td>";
      echo "<td>" . $row['bid'] . "</td>";
      echo "<td>" . $row['name'] . "</td>";
      echo "<td>" . $row['authors'] . "</td>";
      echo "<td>" . $row['edition'] . "</td>";
      echo "<td>" . $row['issue'] . "</td>";
      echo "<td>" . $row['return'] . "</td>";
      echo "<td><input type='checkbox' name='status' value='1' " . ($row['status'] ? 'checked' : '') . "> Đã trả</td>";
      echo "<td><input type='date' name='return_date' value='" . $row['return_date'] . "'></td>";
      echo "<td><input type='hidden' name='bid' value='" . $row['bid'] . "'>";
      echo "<input type='hidden' name='username' value='" . $row['username'] . "'>";
      echo "<input type='submit' name='update' value='Cập nhật'></td>";
      echo "</tr>";
      echo "</form>";
    }
    echo "</table>";
  }

  // Cập nhật trạng thái sách
  if (isset($_POST['update'])) {
    $bid = $_POST['bid'];
    $username = $_POST['username'];
    $status = isset($_POST['status']) ? 1 : 0;
    $return_date = $_POST['return_date'];

    // Cập nhật dữ liệu sách
    $update_sql = "UPDATE issue_book SET status='$status', return_date='$return_date' WHERE bid='$bid' AND username='$username'";
    $update_res = mysqli_query($db, $update_sql);

    if ($update_res) {
      echo "<script>alert('Cập nhật thành công!');</script>";
      echo "<script>window.location.href='expired.php';</script>";
    } else {
      echo "<script>alert('Cập nhật thất bại!');</script>";
    }
  }
  ?>
</div>
</body>
</html>
