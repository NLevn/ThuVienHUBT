<?php 
include "connection.php";
include "navbar.php";

// Khởi tạo phiên nếu chưa tồn tại
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Hồ Sơ</title>
    <style type="text/css">
        .wrapper
        {
            width: 300px;
            margin: 0 auto;
            color: white;
        }
    </style>
</head>
<body style="background-color: #223647;">
    <div class="container">
        <form action="" method="post">
            <button class="btn btn-default" style="float: right; width: 70px;" name="submit1">Sửa</button>
        </form>
        <div class="wrapper">
            <?php
            if(isset($_POST['submit1']))
            {
                ?>
                <script type="text/javascript">
                    window.location = "edit.php";
                </script>
                <?php
            }

            // Kiểm tra phiên và thực hiện truy vấn
            if(isset($_SESSION['login_user'])) {
                $username = $_SESSION['login_user'];
                $q = mysqli_query($db, "SELECT * FROM admin WHERE username='$username';");

                if (!$q) {
                    echo "Lỗi: " . mysqli_error($db);
                } else {
                    $row = mysqli_fetch_assoc($q);

                    if ($row) {
                        echo "<h2 style='text-align: center;'>Hồ Sơ Của Tôi</h2>";

                        echo "<div style='text-align: center'>
                            <img class='img-circle profile-img' height=110 width=120 src='images/".$_SESSION['pic']."'>
                        </div>";

                        echo "<div style='text-align: center;'> <b>Chào mừng, </b>
                            <h4>". $_SESSION['login_user'] ."</h4>
                        </div>";

                        echo "<b>";
                        echo "<table class='table table-bordered'>";
                            echo "<tr>";
                            echo "<td><b> Họ: </b></td>";
                                
                                echo "<td>". $row['first'] ."</td>";
                            echo "</tr>";

                            echo "<tr>";
                                echo "<td><b> Tên: </b></td>";
                                echo "<td>". $row['last'] ."</td>";
                            echo "</tr>";

                            echo "<tr>";
                                echo "<td><b> Tên Đăng Nhập: </b></td>";
                                echo "<td>". $row['username'] ."</td>";
                            echo "</tr>";

                            echo "<tr>";
                                echo "<td><b> Mật Khẩu: </b></td>";
                                echo "<td>". $row['password'] ."</td>";
                            echo "</tr>";

                            echo "<tr>";
                                echo "<td><b> Email: </b></td>";
                                echo "<td>". $row['email'] ."</td>";
                            echo "</tr>";

                            echo "<tr>";
                                echo "<td><b> Liên Hệ: </b></td>";
                                echo "<td>". $row['contact'] ."</td>";
                            echo "</tr>";

                        echo "</table>";
                        echo "</b>";
                    } else {
                        echo "<p style='color: red; text-align: center;'>Không tìm thấy thông tin người dùng.</p>";
                    }
                }
            } else {
                echo "<p style='color: red; text-align: center;'>Phiên không tồn tại. Vui lòng đăng nhập lại.</p>";
            }
            ?>
        </div>
    </div>
</body>
</html>
