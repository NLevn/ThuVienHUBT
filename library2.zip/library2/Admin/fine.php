<?php
  include "connection.php";
  include "navbar.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Tính Toán Tiền Phạt</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<style type="text/css">
		.srch {
			padding-left: 850px;
		}
		body {
			font-family: "Lato", sans-serif;
			transition: background-color .5s;
		}
		.sidenav {
			height: 100%;
			margin-top: 50px;
			width: 0;
			position: fixed;
			z-index: 1;
			top: 0;
			left: 0;
			background-color: #222;
			overflow-x: hidden;
			transition: 0.5s;
			padding-top: 60px;
		}
		.sidenav a {
			padding: 8px 8px 8px 32px;
			text-decoration: none;
			font-size: 25px;
			color: #818181;
			display: block;
			transition: 0.3s;
		}
		.sidenav a:hover {
			color: #f1f1f1;
		}
		.sidenav .closebtn {
			position: absolute;
			top: 0;
			right: 25px;
			font-size: 36px;
			margin-left: 50px;
		}
		#main {
			transition: margin-left .5s;
			padding: 16px;
		}
		@media screen and (max-height: 450px) {
			.sidenav {padding-top: 15px;}
			.sidenav a {font-size: 18px;}
		}
		.img-circle {
			margin-left: 20px;
		}
		.h:hover {
			color: white;
			width: 300px;
			height: 50px;
			background-color: #00544c;
		}
	</style>
</head>
<body>

<!-- Sidebar -->
<div id="mySidenav" class="sidenav">
	<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
	<div style="color: white; margin-left: 60px; font-size: 20px;">
		<?php
		if(isset($_SESSION['login_user'])) {
			echo "<img class='img-circle profile_img' height=120 width=120 src='images/".$_SESSION['pic']."'>";
			echo "</br></br>";
			echo "Chào mừng ".$_SESSION['login_user']; 
		}
		?>
	</div>
	<br><br>
	<div class="h"><a href="request.php">Yêu Cầu Sách</a></div>
	<div class="h"><a href="issue_info.php">Thông Tin Mượn Sách</a></div>
	<div class="h"><a href="expired.php">Danh Sách Quá Hạn</a></div>
	<div class="h"><a href="SachQuaHan.php">Sách quá hạn</a></div>
</div>

<!-- Main content -->
<div id="main">
	<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>

	<script>
	function openNav() {
		document.getElementById("mySidenav").style.width = "300px";
		document.getElementById("main").style.marginLeft = "300px";
		document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
	}

	function closeNav() {
		document.getElementById("mySidenav").style.width = "0";
		document.getElementById("main").style.marginLeft= "0";
		document.body.style.backgroundColor = "white";
	}
	</script>

	<!-- Search bar -->
	<div class="container">
		<div class="srch">
			<form class="navbar-form" method="post" name="form1">
				<input class="form-control" type="text" name="search" placeholder="Tên đăng nhập sinh viên.." required="">
				<button style="background-color: #6db6b9e6;" type="submit" name="submit" class="btn btn-default">
					<span class="glyphicon glyphicon-search"></span>
				</button>
			</form>
		</div>

		<h2>Danh Sách Sinh Viên</h2>
		<?php
		if(isset($_POST['submit'])) {
			$q = mysqli_query($db, "SELECT * FROM `fine` where username like '%$_POST[search]%' ");
			if(mysqli_num_rows($q) == 0) {
				echo "Xin lỗi! Không tìm thấy sinh viên nào với tên đăng nhập đó. Hãy thử tìm kiếm lại.";
			} else {
				echo "<table class='table table-bordered table-hover'>";
				echo "<tr style='background-color: #ccc ;'>";
				echo "<th> Tên đăng nhập </th>";
				echo "<th> BID </th>";
				echo "<th> Ngày trả </th>";
				echo "<th> Số ngày </th>";
				echo "<th> Tiền phạt  </th>";
				echo "<th> Trạng thái </th>";
				echo "</tr>";	

				while($row = mysqli_fetch_assoc($q)) {
					echo "<tr>";
					echo "<td>" . $row['username'] . "</td>";
					echo "<td>" . $row['bid'] . "</td>";
					echo "<td>" . $row['returned'] . "</td>";
					echo "<td>" . $row['day'] . "</td>";
					echo "<td>" . $row['fine'] . "</td>";
					echo "<td>" . $row['status'] . "</td>";
					echo "</tr>";
				}
				echo "</table>";
			}
		} else {
			$res = mysqli_query($db, "SELECT * FROM `fine`;");
			echo "<table class='table table-bordered table-hover'>";
			echo "<tr style='background-color: #ccc ;'>";
			echo "<th> Tên đăng nhập </th>";
			echo "<th> BID </th>";
			echo "<th> Ngày trả </th>";
			echo "<th> Số ngày </th>";
			echo "<th> Tiền phạt  </th>";
			echo "<th> Trạng thái </th>";
			echo "</tr>";	

			while($row = mysqli_fetch_assoc($res)) {
				echo "<tr>";
				echo "<td>" . $row['username'] . "</td>";
				echo "<td>" . $row['bid'] . "</td>";
				echo "<td>" . $row['returned'] . "</td>";
				echo "<td>" . $row['day'] . "</td>";
				echo "<td>" . $row['fine'] . "</td>";
				echo "<td>" . $row['status'] . "</td>";
				echo "</tr>";
			}
			echo "</table>";
		}
		?>
	</div>
</div>
</body>
</html>
