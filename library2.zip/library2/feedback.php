<?php
include "connection.php"; // Bao gồm tập tin kết nối cơ sở dữ liệu
include "navbar.php";

// Xử lý dữ liệu từ form (nếu có)
if (isset($_POST['submit'])) {
    // Bảo vệ dữ liệu đầu vào
    $comment = mysqli_real_escape_string($db, $_POST['comment']);
    $username = mysqli_real_escape_string($db, $_SESSION['login_user']); // Lấy tên người dùng từ phiên làm việc

    // Thực hiện truy vấn chèn bình luận vào cơ sở dữ liệu
    $sql = "INSERT INTO `comments` (username, comment) VALUES ('$username', '$comment')";

    if (mysqli_query($db, $sql)) {
        echo "<p class='alert alert-success'>Bình luận đã được gửi.</p>";
    } else {
        echo "<p class='alert alert-danger'>Lỗi: " . mysqli_error($db) . "</p>";
    }
}

// Truy vấn dữ liệu bình luận
$sql = "SELECT * FROM `comments` ORDER BY `id` DESC";
$res = mysqli_query($db, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Phản hồi</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
    <style type="text/css">
      /* styles.css */
body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
    margin: 0;
    padding: 0;
}

.wrapper {
    width: 80%;
    margin: 20px auto;
    padding: 20px;
    background-color: #ffffff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h4 {
    color: #333333;
    margin-bottom: 20px;
}

form {
    margin-bottom: 20px;
}

.form-control {
    width: 100%;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ced4da;
    border-radius: 4px;
}

.btn-default {
    background-color: #007bff;
    color: #ffffff;
    border: none;
    padding: 10px 20px;
    border-radius: 4px;
    cursor: pointer;
}

.btn-default:hover {
    background-color: #0056b3;
}

.alert {
    padding: 10px;
    margin-bottom: 20px;
    border-radius: 4px;
}

.alert-success {
    background-color: #d4edda;
    color: #155724;
}

.alert-danger {
    background-color: #f8d7da;
    color: #721c24;
}

.table {
    width: 100%;
    margin-bottom: 20px;
    border-collapse: collapse;
}

.table th, .table td {
    padding: 10px;
    border: 1px solid #dee2e6;
}

.table th {
    background-color: #f1f1f1;
}

.scroll {
    max-height: 400px;
    overflow-y: auto;
    border: 1px solid #dee2e6;
    padding: 10px;
    border-radius: 4px;
}

    </style>
</head>
<body>

    <div class="wrapper">
        <h4>Nếu bạn có góp ý hoặc thắc mắc vui lòng bình luận bên dưới và hãy giới thiệu những cuốn sách đến với thư viện HUBT</h4>
        <form action="" method="post">
            <input class="form-control" type="text" name="comment" placeholder="Nhập tại đây..."><br>    
            <input class="btn btn-default" type="submit" name="submit" value="Gửi">        
        </form>
    
        <div class="scroll">
            <?php
                if ($res) {
                    echo "<table class='table'>";
                    echo "<thead><tr><th> Người dùng</th><th>Bình luận</th></tr></thead>";
                    echo "<tbody>";
                    while ($row = mysqli_fetch_assoc($res)) {
                        echo "<tr>";
                        echo "<td>"; echo htmlspecialchars($row['username']); echo "</td>";
                        echo "<td>"; echo htmlspecialchars($row['comment']); echo "</td>";
                        echo "</tr>";
                    }
                    echo "</tbody>";
                    echo "</table>";
                } else {
                    echo "<p class='alert alert-danger'>Lỗi truy vấn: " . mysqli_error($db) . "</p>";
                }
            ?>
        </div>
    </div>
    
</body>
</html>
