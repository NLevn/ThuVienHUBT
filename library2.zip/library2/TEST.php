<?php
  include "connection.php";
  include "navbar.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Yêu cầu mượn sách</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<style type="text/css">
		.srch
		{
			padding-left: 1000px;

		}
		
		body {
		font-family: "Lato", sans-serif;
		transition: background-color .5s;
		}

		.sidenav {
		height: 100%;
		margin-top: 50px;
		width: 0;
		position: fixed;
		z-index: 1;
		top: 0;
		left: 0;
		background-color: #222;
		overflow-x: hidden;
		transition: 0.5s;
		padding-top: 60px;
		}

		.sidenav a {
		padding: 8px 8px 8px 32px;
		text-decoration: none;
		font-size: 25px;
		color: #818181;
		display: block;
		transition: 0.3s;
		}

		.sidenav a:hover {
		color: white;
		}

		.sidenav .closebtn {
		position: absolute;
		top: 0;
		right: 25px;
		font-size: 36px;
		margin-left: 50px;
		}

		#main {
		transition: margin-left .5s;
		padding: 16px;
		}

		@media screen and (max-height: 450px) {
		.sidenav {padding-top: 15px;}
		.sidenav a {font-size: 18px;}
		}
		.img-circle
		{
			margin-left: 20px;
		}
		.h:hover
		{
			color:white;
			width: 300px;
			height: 50px;
			background-color: #00544c;
		}

	</style>

</head>
<body>
<!--_________________sidenav_______________-->
	
	<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>

  			<div style="color: white; margin-left: 60px; font-size: 20px;">

                <?php
                if(isset($_SESSION['login_user']))
                { 	
                	echo "<img class='img-circle profile_img' height=120 width=120 src='images/".$_SESSION['pic']."'>";
                    echo "</br></br>";

                    echo "Welcome ".$_SESSION['login_user']; 
                }
                ?>
            </div><br><br>

 
  <div class="h"> <a href="books.php">Sách</a></div>
  <div class="h"> <a href="request.php">Yêu cầu mượn sách</a></div>
  <div class="h"> <a href="issue_info.php">Thông tin mượn sách</a></div>


</div>
<div id="main">
  
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; </span>
<div class="container">

	<script>
	function openNav() {
	  document.getElementById("mySidenav").style.width = "300px";
	  document.getElementById("main").style.marginLeft = "300px";
	  document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
	}

	function closeNav() {
	  document.getElementById("mySidenav").style.width = "0";
	  document.getElementById("main").style.marginLeft= "0";
	  document.body.style.backgroundColor = "white";
	}
	</script>
	<br><br>
	
	<?php
	
	$q = mysqli_query($db, "SELECT * from ban_doc where username='$_SESSION[login_user]'  ;");

	if (mysqli_num_rows($q) == 0)
	{
		echo "<h1>Không có yêu cầu mượn sách!</h1>";
	}
	else
	{
		echo "<form action='' method='post'>";
		echo "<table class='table table-bordered table-hover' >";
		echo "<tr style='background-color: #ccc;'>";
		// Table header
		echo "<th>"; echo "Chọn";  echo "</th>";
		echo "<th>"; echo "Mã sách";  echo "</th>";
		echo "<th>"; echo "Tên sách";  echo "</th>";
		// echo "<th>"; echo "Ngày mượn";  echo "</th>";
		// echo "<th>"; echo "Ngày trả";  echo "</th>";
		// echo "</tr>";	

		while($row = mysqli_fetch_assoc($q))
		{
			echo "<tr>";
			echo "<td><input type='checkbox' name='check[]' value='" . $row['bid'] . "'></td>";
			echo "<td>"; echo $row['bid']; echo "</td>";
			echo "<td>"; echo $row['name']; echo "</td>";
			echo "</tr>";
		}
		echo "</table>";
		echo "<p align='center'><button type='submit' name='delete' class='btn btn-success'>Xóa</button></p>";
        echo "<p align='center'><button type='submit' name='request' class='btn btn-success'>Yêu cầu mượn sách</button></p>";
		echo "</form>";
	}
	?>
</div>
</div>
<?php
	if (isset($_POST['delete'])) {
		if (isset($_POST['check'])) {
			foreach ($_POST['check'] as $delete_id) {
				mysqli_query($db, "DELETE from ban_doc where bid='$delete_id' and username='$_SESSION[login_user]' order by bid ASC limit 1;");
			}
			echo "<script>window.location.reload();</script>";
		}
	}
    if(isset($_POST['submit1']))
		{
			if(isset($_SESSION['login_user']))
			{
				mysqli_query($db,"INSERT INTO issue_book Values('$_SESSION[login_user]', '$_POST[bid]', '', '', '');");
				?>
					<script type="text/javascript">
						window.location="request.php"
					</script>
				<?php
			}
			else
			{
				?>
					<script type="text/javascript">
						alert("You must login to Request a book");
					</script>
				<?php
			}
		}
?>
</body>
</html>
