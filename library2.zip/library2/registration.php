<?php
  include "connection.php";
  include "navbar.php";
?>

<!DOCTYPE html>
<html>
<head>

  <title>Đăng kí thành viên</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <style type="text/css">
      .box {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background-color: #ffffff;
    padding: 20px 40px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    max-width: 400px;
    text-align: left;
      }

      .box p {
          font-size: 15px;
          font-weight: 700;
          margin-bottom: 15px;
          color: #333;
      }

      .box input[type="radio"] {
          margin-left: 10px;
          width: 18px;
          height: 18px;
      }

      .box label {
          margin-left: 5px;
          font-size: 14px;
          color: #555;
      }

      .box .btn {
          background-color: #007bff;
          color: white;
          width: 70px;
          height: 30px;
          font-size: 14px;
          border: none;
          border-radius: 5px;
          cursor: pointer;
          transition: background-color 0.3s ease;
          margin-left: 20px;
      }

      .box .btn:hover {
          background-color: #0056b3;
      }

  </style>   
</head>
<body>
<div class="box">
      <form  name="signup" action="" method="post">
        <b><p style="padding-left:50px; font: size 15px;font-weight:700">Đăng nhập:</p></b>
       
        <input style="margin-left: 50px; width:18px" type="radio" name="user" id="admin" value="admin">
        <label for="admin" >Thủ thư</label>
        
        <input style="margin-left: 50px; width:18px" type="radio" name="user" id="student" value="student">
        <label for="student">Sinh viên</label> &nbsp&nbsp&nbsp&nbsp
      <button class="btn btn-default" type="submit" name="submit1" style="color:black;width: 70px; height:30px"
      >OK</button>
    </form>
    </div>
    <?php
      if(isset($_POST['submit1'])){
        if($_POST['user']=='admin'){
          ?>
          <script type="text/javascript">
            window.location="Admin/registration.php"
          </script><?php
        }else{
          ?>
          <script type="text/javascript">
            window.location="Student/registration.php"
          </script><?php
        }
      }
    ?>
</body>
</html>