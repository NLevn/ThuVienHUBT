<?php
include "connection.php"; // Kết nối tới cơ sở dữ liệu
include "navbar.php"; // Thanh điều hướng

if (isset($_GET['bid'])) {
    $book_id = $_GET['bid']; // Lấy mã sách từ URL
    $q = mysqli_query($db, "SELECT * FROM books WHERE bid='$book_id'");
    $book = mysqli_fetch_assoc($q);

    if ($book) {
        echo "<h2>Chi tiết sách</h2>";
        echo "<p><strong>Tên sách:</strong> {$book['name']}</p>";
        echo "<p><strong>Mã sách:</strong> {$book['bid']}</p>";
        echo "<p><strong>Tác giả:</strong> {$book['authors']}</p>";
        echo "<p><strong>Phiên bản:</strong> {$book['edition']}</p>";
        echo "<p><strong>Trạng thái:</strong> {$book['status']}</p>";
        echo "<p><strong>Số lượng:</strong> {$book['quantity']}</p>";
        echo "<p><strong>Vị trí:</strong> {$book['department']}</p>";
        echo "<p><strong>Mô Tả:</strong> {$book['introduce']}</p>";
    } else {
        echo "Không tìm thấy sách.";
    }
} else {
    echo "Không có sách nào được chọn.";
}
?>
<form action="" method="post">
            <input class="form-control" type="text" name="comment" placeholder="Nhập tại đây..."><br>    
            <input class="btn btn-default" type="submit" name="submit" value="Gửi">        
        </form>
    
        <div class="scroll">
            <?php
               
                    echo "<thead><tr><th> Người dùng</th><th>đánh giá</th></tr></thead>";
                    echo "<tbody>";
                    while ($row = mysqli_fetch_assoc($res)) {
                        echo "<tr>";
                        echo "<td>"; echo htmlspecialchars($row['username']); echo "</td>";
                        echo "<td>"; echo htmlspecialchars($row['comment']); echo "</td>";
                        echo "</tr>";
                    }
                    echo "</tbody>";
                    echo "</table>";
                
            ?>
        </div>
        <?php
if (isset($_POST['submit'])) {
    // Bảo vệ dữ liệu đầu vào
    $comment = mysqli_real_escape_string($db, $_POST['comment']);
    $username = mysqli_real_escape_string($db, $_SESSION['login_user']); // Lấy tên người dùng từ phiên làm việc

    // Thực hiện truy vấn chèn bình luận vào cơ sở dữ liệu
    $sql = "INSERT INTO `reviews` (username, comment) VALUES ('$username', '$comment')";

    if (mysqli_query($db, $sql)) {
        echo "<p class='alert alert-success'>Bình luận đã được gửi.</p>";
    } else {
        echo "<p class='alert alert-danger'>Lỗi: " . mysqli_error($db) . "</p>";
    }
}

// Truy vấn dữ liệu bình luận
$sql = "SELECT * FROM `comments` ORDER BY `id` DESC";
$res = mysqli_query($db, $sql);
?>
        