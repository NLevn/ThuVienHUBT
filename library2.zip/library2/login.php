<?php
  include "connection.php";
  include "navbar.php";
?>

<!DOCTYPE html>
<html>
<head>

  <title>Student Login</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  
  <style type="text/css">
    
    section
    {
      margin-top: -20px;
    }
    .box1 {
    background-color: #f8f9fa; /* Màu nền nhạt */
    padding: 20px 40px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Tạo bóng */
    max-width: 400px;
    margin: 0 auto;
    text-align: center;
    }

    .box1 h1:first-child {
        font-size: 35px;
        font-family: 'Lucida Console', monospace;
        margin-bottom: 10px;
        color: #333;
    }

    .box1 h1:nth-child(2) {
        font-size: 25px;
        margin-bottom: 20px;
        color: #555;
    }

    .box1 p {
        font-size: 15px;
        font-weight: 700;
        text-align: left;
        margin-bottom: 15px;
        color: #333;
    }

    .box1 input[type="radio"] {
        margin-left: 10px;
        width: 18px;
        height: 18px;
    }

    .box1 label {
        margin-left: 5px;
        font-size: 14px;
        color: #555;
    }

    .box1 .login {
        margin-top: 20px;
    }

    .box1 .form-control {
        width: 100%;
        padding: 10px;
        margin-bottom: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 14px;
    }

    .box1 .btn {
        background-color: #007bff;
        color: white;
        width: 100px;
        height: 35px;
        font-size: 14px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .box1 .btn:hover {
        background-color: #0056b3;
    }

    .box1 p a {
        color: yellow;
        text-decoration: none;
    }

    .box1 p a:hover {
        text-decoration: underline;
    }

  </style>   
</head>
<body>

<section>
  <div class="log_img">
   <br>
    <div class="box1">
        <h1 style="text-align: center; font-size: 35px;font-family: Arial, Helvetica, sans-serif;">Thư viện HUBT</h1>
        <h1 style="text-align: center; font-size: 25px;">Đăng nhập người dùng</h1><br>
      <form  name="login" action="" method="post">
        <b><p style="padding-left:50px; font: size 15px;font-weight:700">Đăng nhập với:</p></b>
       
        <input style="margin-left: 50px; width:18px" type="radio" name="user" id="admin" value="admin">
        <label for="admin" >Thủ thư</label>
        
        <input style="margin-left: 50px; width:18px" type="radio" name="user" id="student" value="student">
        <label for="student">Sinh viên</label>
        <div class="login">
          <input class="form-control" type="text" name="username" placeholder="Tên đăng nhập" required=""> <br>
          <input class="form-control" type="password" name="password" placeholder="Mật khẩu" required=""> <br>
          <input class="btn btn-default" type="submit" name="submit" value="Đăng nhập" style="color: black; width: 100px; height: 30px"> 
        </div>
      
      <p style="color: white; padding-left: 15px;">
        <br><br>
        <a style="color:red; text-decoration: none;" href="forgot_password.php">Quên mật khẩu?</a> &nbsp &nbsp &nbsp &nbsp &nbsp 
        <a style="color: red; text-decoration: none;" href="registration.php">&nbspĐăng kí</a>
      </p>
    </form>
    </div>
  </div>
</section>

  <?php

    if(isset($_POST['submit']))
    {
      if($_POST['user']=='admin'){
        $count=0;
      $res=mysqli_query($db,"SELECT * FROM `admin` WHERE username='$_POST[username]' and password='$_POST[password]' and status = 'yes';");
      
      $row= mysqli_fetch_assoc($res);
      $count=mysqli_num_rows($res);

      if($count==0)
      {
        ?>s
          <div class="alert alert-danger" style="width: 600px; margin-left: 370px; background-color: #de1313; color: white">
            <strong>Tên đăng nhập hoặc mật khẩu không đúng</strong>
          </div>    
        <?php
      }
      else
      {
        $_SESSION['login_user'] = $_POST['username'];
        $_SESSION['pic']= $row['pic'];

        ?>
          <script type="text/javascript">
            window.location="Admin/books.php"
          </script>
        <?php
      }
      }else{
      $count=0;
      $res=mysqli_query($db,"SELECT * FROM `student` WHERE username='$_POST[username]' && password='$_POST[password]';");
      
      $row= mysqli_fetch_assoc($res);
      $count=mysqli_num_rows($res);

      if($count==0)
      {
        ?>
          <div class="alert alert-danger" style="width: 600px; margin-left: 370px; background-color: #de1313; color: white">
            <strong>Tên đăng nhập hoặc mật khẩu không đúng</strong>
          </div>    
        <?php
      }
      else
      {
        $_SESSION['login_user'] = $_POST['username'];
        $_SESSION['pic']= $row['pic'];

        ?>
          <script type="text/javascript">
            window.location="Student/books.php"
          </script>
        <?php
      }
    }
}
  ?>

</body>
</html>