<?php
  include "connection.php";
  include "navbar.php";
?>

<!DOCTYPE html>
<html>
<head>
  <title>Quên mật khẩu</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <style type="text/css">
    body {
      height: 650px;
      background-image: url("images/7.jpg");
      background-repeat: no-repeat;
    }
    .wrapper {
      width: 400px;
      height: 400px;
      margin:100px auto;
      background-color: black;
      opacity: .8;
      color: white;
      padding: 27px 15px;
    }
    .form-control {
      width: 300px;
    }
  </style>
</head>
<body>
  <div class="wrapper">
    <div style="text-align: center;">
      <h1 style="text-align: center; font-size: 35px;font-family: Lucida Console;">Quên mật khẩu</h1>
    </div>
    <div style="padding-left: 30px;">
      <form action="handle_forgot_password.php" method="post">
        <input type="text" name="username" class="form-control" placeholder="Tên người dùng" required=""><br>
        <button class="btn btn-default" type="submit" name="submit">Gửi yêu cầu</button>
      </form>
    </div>
  </div>
</body>
</html>
