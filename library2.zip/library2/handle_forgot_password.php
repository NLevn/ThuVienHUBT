<?php
include "connection.php";

if (isset($_POST['submit'])) {
  $username = $_POST['username'];

  // Kiểm tra trong bảng admin
  $res_admin = mysqli_query($db, "SELECT * FROM `admin` WHERE username='$username'");
  $count_admin = mysqli_num_rows($res_admin);

  // Kiểm tra trong bảng student
  $res_student = mysqli_query($db, "SELECT * FROM `student` WHERE username='$username'");
  $count_student = mysqli_num_rows($res_student);

  if ($count_admin > 0) {
    header("Location: Admin/update_password.php?username=" . $username);
  } elseif ($count_student > 0) {
    header("Location: Student/update_password.php?username=" . $username);
  } else {
    echo "<script>alert('Tên người dùng không tồn tại.'); window.location='forgot_password.php';</script>";
  }
}
?>
